package com.sniper.arbademo.manager

import android.content.Context
import android.content.pm.PackageManager
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import java.lang.ref.WeakReference
import java.util.concurrent.ConcurrentHashMap

/**
 * 权限管理器
 * 用于处理应用权限请求，不直接与Activity绑定，支持被其他Manager调用
 */
class PermissionManager private constructor() {

    companion object {
        private const val TAG = "PermissionManager"

        // 单例实例
        @Volatile
        private var INSTANCE: PermissionManager? = null

        /**
         * 获取PermissionManager实例
         */
        fun getInstance(): PermissionManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: PermissionManager().also { INSTANCE = it }
            }
        }

        /**
         * 检查权限是否已授予（静态方法）
         */
        fun hasPermission(context: Context, permission: String): Boolean {
            return ContextCompat.checkSelfPermission(
                context,
                permission
            ) == PackageManager.PERMISSION_GRANTED
        }

        /**
         * 检查多个权限是否已授予（静态方法）
         */
        fun hasPermissions(context: Context, vararg permissions: String): Boolean {
            return permissions.all { hasPermission(context, it) }
        }
    }

    // 权限回调接口
    interface PermissionCallback {
        /**
         * 权限授予成功
         */
        fun onPermissionGranted(permissions: Array<String>)

        /**
         * 权限被拒绝
         */
        fun onPermissionDenied(permissions: Array<String>)
    }

    // 使用WeakReference存储Activity引用，避免内存泄漏
    private var currentActivityRef: WeakReference<ComponentActivity>? = null

    // 存储权限请求回调
    private val permissionCallbacks = ConcurrentHashMap<String, PermissionCallback>()

    // 存储不同Activity的权限请求启动器
    private val permissionLaunchers = ConcurrentHashMap<ComponentActivity, androidx.activity.result.ActivityResultLauncher<Array<String>>>()

    /**
     * 设置当前Activity
     * 在Activity的onCreate中调用此方法
     */
    fun setCurrentActivity(activity: ComponentActivity) {
        // 存储Activity的弱引用
        currentActivityRef = WeakReference(activity)

        // 如果此Activity还没有注册权限请求启动器，则注册
        if (!permissionLaunchers.containsKey(activity)) {
            val launcher = activity.registerForActivityResult(
                ActivityResultContracts.RequestMultiplePermissions()
            ) { permissions ->
                handlePermissionResult(permissions)
            }
            permissionLaunchers[activity] = launcher

            // 监听Activity生命周期，在销毁时清理资源
            activity.lifecycle.addObserver(object : DefaultLifecycleObserver {
                override fun onDestroy(owner: LifecycleOwner) {
                    permissionLaunchers.remove(activity)
                    owner.lifecycle.removeObserver(this)
                }
            })
        }
    }

    /**
     * 请求单个权限
     * 如果已经有权限，直接回调成功
     * 如果没有设置Activity，返回false
     */
    fun requestPermission(context: Context, permission: String, callback: PermissionCallback): Boolean {
        return requestPermissions(context, arrayOf(permission), callback)
    }

    /**
     * 请求多个权限
     * 如果已经有所有权限，直接回调成功
     * 如果没有设置Activity，返回false
     */
    fun requestPermissions(context: Context, permissions: Array<String>, callback: PermissionCallback): Boolean {
        // 检查是否已经有所有权限
        if (hasPermissions(context, *permissions)) {
            callback.onPermissionGranted(permissions)
            return true
        }

        // 获取当前Activity
        val currentActivity = currentActivityRef?.get()
        if (currentActivity == null || currentActivity.isFinishing || currentActivity.isDestroyed) {
            return false
        }

        // 生成请求ID
        val requestId = System.nanoTime().toString()
        permissionCallbacks[requestId] = callback

        // 存储当前请求ID到Activity的Intent中，用于跟踪
        currentActivity.intent.putExtra("CURRENT_PERMISSION_REQUEST_ID", requestId)
        currentActivity.intent.putExtra("CURRENT_PERMISSION_REQUEST", permissions)

        // 启动权限请求
        val launcher = permissionLaunchers[currentActivity]
        if (launcher != null) {
            launcher.launch(permissions)
            return true
        }

        return false
    }

    /**
     * 处理权限请求结果
     */
    private fun handlePermissionResult(permissions: Map<String, Boolean>) {
        val grantedPermissions = mutableListOf<String>()
        val deniedPermissions = mutableListOf<String>()

        // 分类权限
        permissions.forEach { (permission, granted) ->
            if (granted) {
                grantedPermissions.add(permission)
            } else {
                deniedPermissions.add(permission)
            }
        }

        // 获取当前Activity
        val currentActivity = currentActivityRef?.get() ?: return

        // 获取请求ID
        val requestId = currentActivity.intent?.getStringExtra("CURRENT_PERMISSION_REQUEST_ID")
        val callback = requestId?.let { permissionCallbacks.remove(it) } ?: return

        // 执行回调
        if (deniedPermissions.isEmpty()) {
            callback.onPermissionGranted(grantedPermissions.toTypedArray())
        } else {
            callback.onPermissionDenied(deniedPermissions.toTypedArray())
        }
    }

    /**
     * 清理所有引用和回调
     */
    fun clear() {
        currentActivityRef = null
        permissionCallbacks.clear()
        permissionLaunchers.clear()
    }
}

// 扩展函数：在Activity中快速设置PermissionManager
fun ComponentActivity.setupPermissionManager() {
    PermissionManager.getInstance().setCurrentActivity(this)
}
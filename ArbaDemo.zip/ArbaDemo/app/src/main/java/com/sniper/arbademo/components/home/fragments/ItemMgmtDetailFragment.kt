package com.sniper.arbademo.components.home.fragments

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import coil3.load
import com.sniper.arbademo.R
import com.sniper.arbademo.components.camera.manager.CameraManager
import com.sniper.arbademo.components.home.model.Item
import com.sniper.arbademo.components.home.viewmodel.ItemMgmtDetailViewModel
import com.sniper.arbademo.network.NetworkConfig
import java.io.File

class ItemMgmtDetailFragment : Fragment() {
    private lateinit var etName: EditText
    private lateinit var etContent: EditText
    private lateinit var btnTakePhoto: Button
    private lateinit var ivPreview: ImageView
    private lateinit var btnSubmit: Button
    private lateinit var btnBack: ImageButton
    private lateinit var progressBar: ProgressBar
    private lateinit var viewModel: ItemMgmtDetailViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // 初始化ViewModel
        viewModel = ViewModelProvider(this)[ItemMgmtDetailViewModel::class.java]
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_item_mgmt_detail, container, false)
        
        // 初始化UI元素
        etName = view.findViewById(R.id.et_name)
        etContent = view.findViewById(R.id.et_content)
        btnTakePhoto = view.findViewById(R.id.btn_take_photo)
        ivPreview = view.findViewById(R.id.iv_preview)
        btnSubmit = view.findViewById(R.id.btn_submit)
        btnBack = view.findViewById(R.id.btn_back)
        progressBar = ProgressBar(requireContext()) // 假设布局中已有进度条，如果没有需要添加
        
        // 从arguments中获取Item对象
        arguments?.getParcelable<Item>(ARG_ITEM)?.let { item ->
            // 如果Item对象不为空，设置到输入框中（编辑模式）
            etName.setText(item.name)
            etContent.setText(item.content)
            // 如果有图片URL，让ViewModel准备图片数据，然后使用Coil加载
            if (!item.itemimage.isNullOrEmpty()) {
                val imageUrl = "${NetworkConfig.BASE_URL}${item.itemimage}"
                // 让ViewModel准备图片数据
                viewModel.prepareImageForCoil(imageUrl)
                // 直接使用Coil库加载图片
                ivPreview.load(imageUrl) {
                    // 添加占位图和错误处理
//                    placeholder(R.drawable.ic_launcher_background) // 替换为合适的占位图
//                    error(R.drawable.ic_launcher_foreground) // 替换为合适的错误图
                    listener(
                        onError = { request, result ->
                            Log.e("ItemMgmtDetailFragment", "加载图片失败: ${result.throwable?.message}")
                            showToast("加载图片失败")
                        }
                    )
                }
            }
        }
        
        // 初始化CameraManager
        CameraManager.getInstance().initialize(this)
        
        // 观察ViewModel状态
        observeViewModel()
        
        // 设置返回按钮点击事件
        btnBack.setOnClickListener {
            // 返回上一个界面
            requireActivity().onBackPressedDispatcher.onBackPressed()
        }
        
        // 设置拍照按钮点击事件
        btnTakePhoto.setOnClickListener {
            openCamera()
        }
        
        // 设置提交按钮点击事件
        btnSubmit.setOnClickListener {
            viewModel.submitItem(
                etName.text.toString().trim(),
                etContent.text.toString().trim(),
                viewModel.imageUrl.value
            )
        }
        
        return view
    }
    
    override fun onDestroyView() {
        super.onDestroyView()
        // 清理CameraManager资源
        CameraManager.cleanup(this)
    }
    
    private fun observeViewModel() {
        // 观察加载状态
        viewModel.isLoading.observe(viewLifecycleOwner) { isLoading ->
            if (isLoading) {
                progressBar.visibility = View.VISIBLE
                btnSubmit.isEnabled = false
                btnTakePhoto.isEnabled = false
            } else {
                progressBar.visibility = View.GONE
                btnSubmit.isEnabled = true
                btnTakePhoto.isEnabled = true
            }
        }
        
        // 观察错误信息
        viewModel.errorMessage.observe(viewLifecycleOwner) { errorMsg ->
            errorMsg?.let {
                showToast(it)
                viewModel.clearError()
            }
        }
        
        // 观察图片URI（用于预览）
        viewModel.imageUri.observe(viewLifecycleOwner) { uri ->
            uri?.let {
                // 打印URI（调试用）
                Log.d("ItemMgmtDetailFragment", "Image URI: $it")
                ivPreview.setImageURI(it)
//                showToast("拍照成功")
            }
        }
        
        // 观察提交成功状态
        viewModel.submitSuccess.observe(viewLifecycleOwner) { isSuccess ->
            if (isSuccess) {
                showToast("新增物品成功")
                viewModel.resetSubmitSuccess()
                // 返回上一页
                parentFragmentManager.popBackStack()
            }
        }
    }
    
    private fun openCamera() {
        try {
            CameraManager.takePhoto(this) {
                onImageCaptured = { imageFile ->
                    // 使用ViewModel上传图片
                    viewModel.uploadImage(imageFile)
                }
                onCameraCanceled = {
                    requireActivity().runOnUiThread {
                        showToast("拍照已取消")
                    }
                }
                onError = {
                    requireActivity().runOnUiThread {
                        showToast("拍照出错")
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            showToast("无法启动相机: ${e.message}")
        }
    }
    
    private fun showToast(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
    }

    companion object {
        private const val ARG_ITEM = "item"
        
        @JvmStatic
        fun newInstance(item: Item? = null) =
            ItemMgmtDetailFragment().apply {
                arguments = Bundle().apply {
                    if (item != null) {
                        // 将Item对象存储在Bundle中
                        putParcelable(ARG_ITEM, item)
                    }
                }
            }
    }
}
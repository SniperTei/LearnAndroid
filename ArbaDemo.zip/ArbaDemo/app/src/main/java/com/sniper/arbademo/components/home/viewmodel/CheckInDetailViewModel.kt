package com.sniper.arbademo.components.home.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import com.sniper.arbademo.components.home.model.Item
import com.sniper.arbademo.components.home.repository.CheckInRepository
import com.sniper.arbademo.network.NetworkCallback

/**
 * 打卡详情页面的ViewModel
 * 负责处理打卡记录的保存、更新等操作
 */
class CheckInDetailViewModel : ViewModel() {
    // 初始化Repository实例
    private val repository = CheckInRepository()
    
    /**
     * 保存打卡记录的监听器接口
     */
    interface SaveListener {
        fun onSuccess()
        fun onError(message: String)
    }
    
    /**
     * 执行打卡的监听器接口
     */
    interface CheckInListener {
        fun onSuccess()
        fun onError(message: String)
    }
    
    /**
     * 保存打卡记录（新增或更新）
     * @param item 打卡记录对象
     * @param listener 保存结果监听器
     */
    fun saveCheckIn(item: Item, listener: SaveListener) {
        // 调用Repository的saveCheckIn方法
//        repository.saveCheckIn(item, object : NetworkCallback<Map<String, Any>> {
//            override fun onSuccess(data: Any) {
//                listener.onSuccess()
//            }
//
//            override fun onFailure(message: String) {
//                listener.onError(message)
//            }
//        })
    }
    
    /**
     * 获取打卡记录详情
     * @param itemId 打卡记录ID
     * @param listener 获取结果监听器
     */
    fun getCheckInDetail(itemId: String, listener: GetDetailListener) {
        // 调用Repository的getCheckInDetail方法

    }
    
    /**
     * 获取打卡详情的监听器接口
     */
    interface GetDetailListener {
        fun onSuccess(item: Item?)
        fun onError(message: String)
    }
    
    /**
     * 执行打卡操作
     * @param itemsId 物品ID
     * @param fileName 打卡照片文件名
     * @param listener 打卡结果监听器
     */
    fun performCheckIn(itemsId: String, fileName: String, listener: CheckInListener) {
        // 调用Repository的performCheckIn方法
        Log.d("CheckInDetailViewModel", "执行打卡操作，物品ID: $itemsId, 文件名: $fileName")
        repository.performCheckIn(itemsId, fileName, object : NetworkCallback<Any> {
            override fun onSuccess(data: Any) {
                listener.onSuccess()
            }

            override fun onFailure(errorCode: Int, errorMsg: String) {
                listener.onError(errorMsg)
            }

            override fun onComplete() {

            }
        })
    }
}
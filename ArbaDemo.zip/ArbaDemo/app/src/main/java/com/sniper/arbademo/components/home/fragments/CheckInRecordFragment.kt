package com.sniper.arbademo.components.home.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.sniper.arbademo.components.imagebrowse.activity.ImageBrowseActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil3.load
import com.sniper.arbademo.R
import com.sniper.arbademo.base.fragment.BaseFragment
import com.sniper.arbademo.components.home.model.CheckInRecord
import com.sniper.arbademo.components.home.viewmodel.CheckInRecordViewModel
import com.sniper.arbademo.databinding.FragmentCheckInRecordBinding
import com.sniper.arbademo.network.NetworkConfig

/**
 * 打卡记录列表页面
 * 采用完整MVVM架构模式，使用CheckInRecordViewModel获取数据
 */
class CheckInRecordFragment : BaseFragment() {

    private lateinit var viewModel: CheckInRecordViewModel
    private lateinit var adapter: CheckInRecordAdapter
    private var _binding: FragmentCheckInRecordBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentCheckInRecordBinding.inflate(inflater, container, false)
        
        // 初始化ViewModel
        viewModel = ViewModelProvider(this)[CheckInRecordViewModel::class.java]
        
        // 设置RecyclerView
        binding.recyclerViewCheckIn.layoutManager = LinearLayoutManager(requireContext())
        
        // 加载打卡记录
        loadCheckInRecords()
        
        return binding.root
    }
    
    /**
     * 加载打卡记录列表
     */
    private fun loadCheckInRecords() {
        viewModel.loadCheckInRecords(listener = object : CheckInRecordViewModel.CheckInStateListener {
            override fun onLoading() {
                showLoading()
            }

            override fun onSuccess(records: List<CheckInRecord>?) {
                hideLoading()
                showRecords(records)
            }

            override fun onError(message: String) {
                hideLoading()
                showError(message)
            }
        })
    }
    
    private fun showLoading() {
        binding.progressBar.visibility = View.VISIBLE
        binding.recyclerViewCheckIn.visibility = View.GONE
        binding.emptyView.visibility = View.GONE
    }
    
    private fun hideLoading() {
        binding.progressBar.visibility = View.GONE
    }
    
    private fun showRecords(records: List<CheckInRecord>?) {
        if (records.isNullOrEmpty()) {
            binding.recyclerViewCheckIn.visibility = View.GONE
            binding.emptyView.visibility = View.VISIBLE
        } else {
            binding.recyclerViewCheckIn.visibility = View.VISIBLE
            binding.emptyView.visibility = View.GONE
            // 设置适配器
            adapter = CheckInRecordAdapter(records)
            binding.recyclerViewCheckIn.adapter = adapter
        }
    }
    
    /**
     * 显示错误信息
     */
    private fun showError(message: String) {
        binding.recyclerViewCheckIn.visibility = View.GONE
        binding.emptyView.visibility = View.VISIBLE
        binding.emptyView.text = message
    }
    
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
    
    /**
     * 打卡记录列表适配器
     */
    private inner class CheckInRecordAdapter(private var records: List<CheckInRecord>) : 
        RecyclerView.Adapter<CheckInRecordAdapter.RecordViewHolder>() {
        
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecordViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_check_in_record, parent, false)
            return RecordViewHolder(view)
        }
        
        override fun onBindViewHolder(holder: RecordViewHolder, position: Int) {
            val record = records[position]
            holder.bind(record)
        }
        
        override fun getItemCount(): Int = records.size
        
        inner class RecordViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            private val tvItemId: TextView = itemView.findViewById(R.id.tv_item_id)
            private val tvUsername: TextView = itemView.findViewById(R.id.tv_username)
            private val tvTime: TextView = itemView.findViewById(R.id.tv_time)
            private val tvStatus: TextView = itemView.findViewById(R.id.tv_status)
            private val tvRating: TextView = itemView.findViewById(R.id.tv_rating)
            private val ivItemImage: ImageView = itemView.findViewById(R.id.iv_item_image)
            private val btnScore: TextView = itemView.findViewById(R.id.btn_score)
            
            fun bind(record: CheckInRecord) {
                tvItemId.text = "物品ID: ${record.items_id}"
                tvUsername.text = record.user?.username ?: "未知用户"
//                tvTime.text = record.getFormattedTime()
                tvTime.text = "时间: ${record.updatetime}"
//                tvStatus.text = record.getStatus()
                tvStatus.text = "暂定"
//                tvRating.text = "评分: ${record.score}"
                tvRating.text = "评分: ${record.score}"
                
                // 设置物品图片（简化实现，使用默认图片）
                if (!record.itemsimage.isNullOrEmpty()) {
                    val imageUrl = "${NetworkConfig.BASE_URL}${record.itemsimage}"
                    ivItemImage.load(imageUrl)
                    
                    // 设置图片点击事件 - 使用公共图片浏览组件
                    ivItemImage.setOnClickListener {
                        val imageUrls = listOf(imageUrl)
                        val intent = ImageBrowseActivity.createIntent(itemView.context, imageUrls, 0)
                        startActivity(intent)
                    }
                } else {
                    ivItemImage.setImageResource(android.R.drawable.ic_menu_gallery)
                }
                
                // 设置打分按钮点击事件
                btnScore.setOnClickListener {
                    showScoreDialog(record)
                }
                
                // 添加点击评分的功能
//                tvRating.setOnClickListener {
//                    showScoreDialog(record)
//                }
            }
            
            /**
             * 显示打分对话框
             */
            private fun showScoreDialog(record: CheckInRecord) {
                // 创建输入框
                val editText = android.widget.EditText(itemView.context).apply {
                    hint = "请输入0-100分"
                    inputType = android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL or android.text.InputType.TYPE_CLASS_NUMBER
                    setPadding(80, 40, 80, 40)
                }
                
                // 创建对话框
                AlertDialog.Builder(itemView.context)
                    .setTitle("打分")
                    .setMessage("为物品 ${record.items_id} 输入评分（0-100分，可带小数点）")
                    .setView(editText)
                    .setPositiveButton("确定") { dialog, which ->
                        // 获取输入的评分
                        val inputScore = editText.text.toString()
                        if (inputScore.isNotEmpty()) {
                            try {
                                // 转换为浮点数
                                val scoreValue = inputScore.toFloat()
                                
                                // 验证评分范围
                                if (scoreValue >= 0 && scoreValue <= 100) {
                                    // 显示评分
                                    tvRating.text = "评分: $scoreValue"
                                    val strRecordId = record.id.toString()
                                    // 调用ViewModel的打分方法提交评分（这里可能需要调整参数类型）
                                    viewModel.scoreCheckIn(strRecordId, scoreValue.toInt(), listener = object : CheckInRecordViewModel.CheckInStateListener {
                                        override fun onLoading() {
                                            // 显示加载状态
                                            showToast("正在提交评分...")
                                        }
                                        
                                        override fun onSuccess(records: List<CheckInRecord>?) {
                                            // 更新UI状态
                                            record.score = scoreValue.toInt()
                                            showToast("评分成功")
//                                            tvStatus.text = record.getStatus()
                                        }
                                        
                                        override fun onError(message: String) {
                                            // 显示错误提示
                                            Toast.makeText(itemView.context, message, Toast.LENGTH_SHORT).show()
                                        }
                                    })
                                } else {
                                    // 评分超出范围提示
                                    Toast.makeText(itemView.context, "评分必须在0-100之间", Toast.LENGTH_SHORT).show()
                                }
                            } catch (e: NumberFormatException) {
                                // 输入格式错误提示
                                Toast.makeText(itemView.context, "请输入有效的数字", Toast.LENGTH_SHORT).show()
                            }
                        } else {
                            // 空输入提示
                            Toast.makeText(itemView.context, "请输入评分", Toast.LENGTH_SHORT).show()
                        }
                    }
                    .setNegativeButton("取消") { dialog, which ->
                        dialog.dismiss()
                    }
                    .show()
            }
        }
        
        /**
         * 更新数据集
         */
        fun submitList(newRecords: List<CheckInRecord>?) {
            if (newRecords != null) {
                records = newRecords
                notifyDataSetChanged()
            }
        }
    }
    
    companion object {
        /**
         * 创建Fragment实例的工厂方法
         */
        @JvmStatic
        fun newInstance() = CheckInRecordFragment()
    }
}
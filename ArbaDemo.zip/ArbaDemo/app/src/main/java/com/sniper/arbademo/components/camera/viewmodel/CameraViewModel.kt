package com.sniper.arbademo.components.camera.viewmodel

import android.app.Application
import android.content.Intent
import android.util.Log
import androidx.activity.result.ActivityResult
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.sniper.arbademo.components.camera.model.CameraParams
import com.sniper.arbademo.components.camera.model.CameraState
import com.sniper.arbademo.components.camera.repository.CameraRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

/**
 * 相机视图模型
 */
class CameraViewModel(application: Application) : AndroidViewModel(application) {
    
    private val repository = CameraRepository(application)

    private val TAG = "CameraViewModel"
    
    // 相机状态
    private val _cameraState = MutableStateFlow<CameraState>(CameraState.Idle)
    val cameraState: StateFlow<CameraState> = _cameraState.asStateFlow()
    
    // 当前拍摄的照片文件
    private var currentPhotoFile: File? = null
    
    // 当前相机参数
    private var currentParams: CameraParams? = null
    
    /**
     * 准备相机
     */
    fun prepareCamera(params: CameraParams): Intent {
        val (intent, photoFile) = repository.createCameraIntent(params)
        currentPhotoFile = photoFile
        currentParams = params
        return intent
    }
    
    /**
     * 处理相机结果
     */
    fun handleCameraResult(result: ActivityResult) {
        viewModelScope.launch {
            _cameraState.value = CameraState.Loading
            Log.i(TAG, "_cameraState: $_cameraState.value")
            val photoFile = currentPhotoFile
            val params = currentParams
            
            if (result.resultCode == android.app.Activity.RESULT_OK && photoFile != null && params != null) {
                val cameraResult = repository.processCameraResult(result, photoFile, params)
                if (cameraResult != null) {
                    // 成功时设置状态，状态观察完成后由clearError重置
                    _cameraState.value = CameraState.Success(cameraResult)
                    Log.i(TAG, "_cameraState: $_cameraState.value")
                    
                } else {
                    _cameraState.value = CameraState.Error("处理照片失败")
                    Log.i(TAG, "_cameraState: $_cameraState.value")
                }
            } else if (result.resultCode == android.app.Activity.RESULT_CANCELED && photoFile != null) {
                // 只有当准备了照片文件且用户主动取消时才设置为Cancelled状态
                _cameraState.value = CameraState.Cancelled
                Log.i(TAG, "_cameraState: $_cameraState.value")
            } else {
                _cameraState.value = CameraState.Error("拍照失败")
                Log.i(TAG, "_cameraState: $_cameraState.value")
            }
        }
    }
    
    /**
     * 重置状态
     */
    private fun resetState() {
        currentPhotoFile = null
        currentParams = null
    }
    
    /**
     * 清除错误状态
     */
    fun clearError() {
        if (_cameraState.value is CameraState.Error) {
            _cameraState.value = CameraState.Idle
            Log.i(TAG, "_cameraState: $_cameraState.value")
        }
    }
}
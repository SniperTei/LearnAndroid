package com.sniper.arbademo.components.home.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.sniper.arbademo.components.home.model.CheckInRecord
import com.sniper.arbademo.components.home.model.CheckInRecordListData
import com.sniper.arbademo.components.home.repository.CheckInRepository

/**
 * 打卡记录ViewModel
 * 管理打卡记录数据的状态和操作
 */
class CheckInRecordViewModel : ViewModel() {
    
    // 数据状态监听器接口
    interface CheckInStateListener {
        fun onLoading()
        fun onSuccess(records: List<CheckInRecord>?)
        fun onError(message: String)
    }
    
    private val repository = CheckInRepository()
    private val _checkInRecords = MutableLiveData<List<CheckInRecord>?>()
    val checkInRecords: LiveData<List<CheckInRecord>?> get() = _checkInRecords
    
    private val _errorMessage = MutableLiveData<String>()
    val errorMessage: LiveData<String> get() = _errorMessage
    
    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> get() = _isLoading
    
    /**
     * 加载打卡记录列表
     */
    fun loadCheckInRecords(status: String? = null, username: String? = null, listener: CheckInStateListener) {
        _isLoading.value = true
        listener.onLoading()
        
        repository.getCheckInRecordList(object : com.sniper.arbademo.network.NetworkCallback<CheckInRecordListData> {
            override fun onSuccess(data: CheckInRecordListData) {
                _checkInRecords.value = data.rows
                _isLoading.value = false
                listener.onSuccess(data.rows)
            }
            
            override fun onFailure(errorCode: Int, errorMsg: String) {
                _errorMessage.value = errorMsg
                _isLoading.value = false
                listener.onError(errorMsg)
            }
            
            override fun onComplete() {
                // 完成回调可以在这里处理
            }
        })
    }

    /**
     * 评分打卡记录
     */
    fun scoreCheckIn(recordId: String, score: Int, listener: CheckInStateListener) {
        _isLoading.value = true
        listener.onLoading()
        
        repository.scoreCheckIn(recordId, score, object : com.sniper.arbademo.network.NetworkCallback<Map<String, Any>> {
            override fun onSuccess(data: Map<String, Any>) {
                _isLoading.value = false
                listener.onSuccess(null)
            }
            
            override fun onFailure(errorCode: Int, errorMsg: String) {
                _errorMessage.value = errorMsg
                _isLoading.value = false
                listener.onError(errorMsg)
            }
            
            override fun onComplete() {
                // 完成回调可以在这里处理
            }
        })
    }
}
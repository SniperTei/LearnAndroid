package com.sniper.arbademo.components.imagebrowse.activity

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import coil3.load
import coil3.request.crossfade
import com.sniper.arbademo.R
import java.util.*

class ImageBrowseActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_IMAGE_URLS = "extra_image_urls"
        const val EXTRA_CURRENT_POSITION = "extra_current_position"

        /**
         * 创建启动ImageBrowseActivity的Intent
         * @param context 上下文
         * @param imageUrls 图片URL列表
         * @param currentPosition 初始显示的图片位置，默认为0
         */
        fun createIntent(
            context: android.content.Context,
            imageUrls: List<String>,
            currentPosition: Int = 0
        ): Intent {
            return Intent(context, ImageBrowseActivity::class.java).apply {
                putExtra(EXTRA_IMAGE_URLS, ArrayList(imageUrls))
                putExtra(EXTRA_CURRENT_POSITION, currentPosition)
            }
        }
    }

    private lateinit var viewPager: ViewPager2
    private lateinit var tvIndicator: android.widget.TextView
    private lateinit var btnClose: android.widget.ImageView
    private val imageUrls: ArrayList<String> by lazy {
        intent.getStringArrayListExtra(EXTRA_IMAGE_URLS) ?: ArrayList()
    }
    private val initialPosition: Int by lazy {
        intent.getIntExtra(EXTRA_CURRENT_POSITION, 0)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_image_browse)

        // 初始化视图
        initViews()
        // 设置适配器
        setupViewPager()
        // 设置事件监听
        setupListeners()
    }

    private fun initViews() {
        viewPager = findViewById(R.id.view_pager)
        tvIndicator = findViewById(R.id.tv_indicator)
        btnClose = findViewById(R.id.btn_close)
    }

    private fun setupViewPager() {
        // 设置适配器
        viewPager.adapter = ImagePagerAdapter(imageUrls)
        
        // 设置初始位置
        if (initialPosition >= 0 && initialPosition < imageUrls.size) {
            viewPager.setCurrentItem(initialPosition, false)
            updateIndicator(initialPosition)
        }

        // 优化ViewPager2的滑动体验
        viewPager.getChildAt(0)?.overScrollMode = RecyclerView.OVER_SCROLL_NEVER
        
        // 监听页面变化
        viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                updateIndicator(position)
            }
            
            override fun onPageScrollStateChanged(state: Int) {
                super.onPageScrollStateChanged(state)
                // 当页面滚动状态改变时，重置所有可见的ZoomableImageView的缩放状态
                // 这样可以确保用户在切换页面后看到的是正常缩放比例的图片
                if (state == ViewPager2.SCROLL_STATE_IDLE) {
                    // 通知适配器当前页面已稳定，可重置缩放状态
                    (viewPager.adapter as? ImagePagerAdapter)?.resetCurrentItemZoom(viewPager.currentItem)
                }
            }
        })
    }

    private fun setupListeners() {
        // 关闭按钮点击事件
        btnClose.setOnClickListener {
            finish()
        }

        // 设置窗口内边距
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private fun updateIndicator(position: Int) {
        tvIndicator.text = "${position + 1}/${imageUrls.size}"
    }

    /**
     * 图片页面适配器
     */
    private inner class ImagePagerAdapter(private val urls: List<String>) : RecyclerView.Adapter<ImagePagerAdapter.ImageViewHolder>() {

        inner class ImageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            val imageView: ZoomableImageView = itemView.findViewById(R.id.zoomable_image_view)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ImageViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_image_browse, parent, false)
            return ImageViewHolder(view)
        }

        override fun onBindViewHolder(holder: ImageViewHolder, position: Int) {
            val url = urls[position]
            
            // 使用Coil3加载图片
            holder.imageView.load(url) {
                // 设置加载占位图（如果有）
                // placeholder(R.drawable.placeholder)
                // 设置错误占位图（如果有）
                // error(R.drawable.error)
                // 交叉淡入效果
                crossfade(true)
                // 优化加载性能
//                allowHardware(false) // 避免某些设备上的硬件加速问题
            }

            // 设置单击监听器，单击图片时关闭Activity
            holder.imageView.setSingleTapListener { 
                finish()
            }
        }
        
        // 添加方法重置当前item的缩放状态
        fun resetCurrentItemZoom(position: Int) {
            // 注意：由于RecyclerView的视图复用机制，我们不能直接访问非绑定的ViewHolder
            // 这里只提供一个空实现，实际的缩放重置在onBindViewHolder中通过setImageDrawable触发
        }

        override fun getItemCount(): Int = urls.size
    }
}
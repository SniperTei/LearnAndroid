package com.sniper.arbademo.components.bridge

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.sniper.arbademo.components.camera.activity.CameraActivity
import com.sniper.arbademo.manager.UserManager
import org.json.JSONObject
import java.io.File
import java.io.IOException

class AndroidJavaScriptInterface(
    private val activity: AppCompatActivity,
    private val webView: WebView
) {
    private val TAG = "AndroidJavaScriptInterface"
    private var callbackId: String = ""
    private val REQUEST_CAMERA = 1001
    
    init {
        Log.d(TAG, "初始化 AndroidJavaScriptInterface")
        
        // 设置ActivityResult处理
        if (activity is OnCameraResultListener) {
            (activity as OnCameraResultListener).setJavaScriptInterface(this)
        }
    }
    
    // 用于Activity回调的接口
    interface OnCameraResultListener {
        fun setJavaScriptInterface(jsInterface: AndroidJavaScriptInterface)
    }

    @JavascriptInterface
    fun callNativeMethod(paramsJson: String) {
        try {
            Log.d(TAG, "接收到来自JavaScript的消息: $paramsJson")
            // {"method":"takePhoto","params":{"type":"current"},"callbackId":"callback_1762682013299_8hkwvf82c"}
            val jsonObject = JSONObject(paramsJson)
            val method = jsonObject.getString("method")
            val callbackId = jsonObject.optString("callbackId", "")

            // 处理不同的方法调用
            when (method) {
                "takePhoto" -> handleTakePhoto(callbackId)
                "getUserInfo" -> handleGetUserInfo(callbackId)
                // 可以添加其他方法处理
                else -> handleUnknownMethod(method, callbackId)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun handleTakePhoto(callbackId: String) {
        // 保存回调ID
        this.callbackId = callbackId
        
        // 检查相机权限
        if (ActivityCompat.checkSelfPermission(activity, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            // val result = createErrorResult("需要相机权限")
            // callJavaScriptCallback(callbackId, result)
            // return
            // 请求相机权限
            ActivityCompat.requestPermissions(activity, arrayOf(Manifest.permission.CAMERA), REQUEST_CAMERA)
            return
        }

        // 直接启动CameraActivity
        val intent = Intent(activity, CameraActivity::class.java)
        activity.startActivityForResult(intent, REQUEST_CAMERA)
    }
    
    // 处理相机结果（由Activity调用）
    fun handleCameraResult(resultCode: Int, data: Intent?) {
        if (callbackId.isEmpty()) return
        
        when (resultCode) {
            AppCompatActivity.RESULT_OK -> {
                data?.getStringExtra(CameraActivity.EXTRA_IMAGE_PATH)?.let { imagePath ->
                    // 将图片转换为Base64
                    try {
                        val imageFile = File(imagePath)
                        Log.d(TAG, "图片: $imageFile")
                        val base64Image = convertFileToBase64(imageFile)
                        Log.d(TAG, "base64Image: $base64Image")
                        val resultData = JSONObject()
                        resultData.put("imageBase64", base64Image)
                        val result = createSuccessResult(resultData)
                        callJavaScriptCallback(callbackId, result)
                    } catch (e: Exception) {
                        val result = createErrorResult("图片处理失败: ${e.message}")
                        callJavaScriptCallback(callbackId, result)
                    }
                } ?: run {
                    val result = createErrorResult("图片路径无效")
                    callJavaScriptCallback(callbackId, result)
                }
            }
            AppCompatActivity.RESULT_CANCELED -> {
                val result = createErrorResult("用户取消拍照")
                callJavaScriptCallback(callbackId, result)
            }
            else -> {
                val result = createErrorResult("拍照失败")
                callJavaScriptCallback(callbackId, result)
            }
        }
        
        // 清空回调ID
        callbackId = ""
    }
    
    /**
     * 将文件转换为Base64字符串
     */
    private fun convertFileToBase64(file: File): String {
        return try {
            val bytes = file.readBytes()
            android.util.Base64.encodeToString(bytes, android.util.Base64.DEFAULT)
        } catch (e: IOException) {
            e.printStackTrace()
            ""
        }
    }

    private fun handleGetUserInfo(callbackId: String) {
        val userInfo = JSONObject()
        // 回调UserManager的数据
       userInfo.put("user_id", UserManager.getUserId())
       userInfo.put("token", UserManager.getToken())
       userInfo.put("nickname", UserManager.getNickname())
       userInfo.put("avatar", UserManager.getAvatar())

        val result = createSuccessResult(userInfo)
        callJavaScriptCallback(callbackId, result)
    }

    // 处理未知方法
    private fun handleUnknownMethod(method: String, callbackId: String) {
        val result = createErrorResult("未知方法: $method")
        callJavaScriptCallback(callbackId, result)
    }

    // 创建成功结果JSON
    private fun createSuccessResult(data: Any): String {
        val result = JSONObject()
        result.put("code", "000000")
        result.put("data", data)
        return result.toString()
    }

    // 创建错误结果JSON
    private fun createErrorResult(error: String): String {
        val result = JSONObject()
        result.put("code", "900000")
        result.put("error", error)
        return result.toString()
    }

    // 调用JavaScript回调函数
    private fun callJavaScriptCallback(callbackId: String, result: String) {
        if (callbackId.isNotEmpty()) {
            activity.runOnUiThread {
                Log.d(TAG, "调用JavaScript回调函数: $result")
                webView.evaluateJavascript(
                    "javascript:nativeCallback('$callbackId', $result)",
                    null
                )
            }
        }
    }
}
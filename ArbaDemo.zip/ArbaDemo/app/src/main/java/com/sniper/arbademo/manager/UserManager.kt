package com.sniper.arbademo.manager

import android.content.Context
import android.content.SharedPreferences
import com.sniper.arbademo.components.user.model.UserResponse
import java.lang.ref.WeakReference
import androidx.core.content.edit

object UserManager {
    private const val PREF_NAME = "user_prefs"
    private const val KEY_IS_LOGGED_IN = "is_logged_in"
    private const val KEY_USER_ID = "user_id"
    private const val KEY_USERNAME = "username"
    private const val KEY_NICKNAME = "nickname"
    private const val KEY_MOBILE = "mobile"
    private const val KEY_AVATAR = "avatar"
    private const val KEY_SCORE = "score"
    private const val KEY_TOKEN = "token"
    private const val KEY_CREATETIME = "createtime"
    private const val KEY_EXPIRETIME = "expiretime"
    private const val KEY_EXPIRES_IN = "expires_in"

    private var contextRef: WeakReference<Context>? = null

    fun saveUserLogin(context: Context, userResponse: UserResponse) {
        this.contextRef = WeakReference(context)
        val prefs: SharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putBoolean(KEY_IS_LOGGED_IN, true)
            .putInt(KEY_USER_ID, userResponse.user_id)
            .putString(KEY_USERNAME, userResponse.username)
            .putString(KEY_NICKNAME, userResponse.nickname)
            .putString(KEY_MOBILE, userResponse.mobile)
            .putString(KEY_AVATAR, userResponse.avatar)
            .putInt(KEY_SCORE, userResponse.score)
            .putString(KEY_TOKEN, userResponse.token)
            .putLong(KEY_CREATETIME, userResponse.createtime)
            .putLong(KEY_EXPIRETIME, userResponse.expiretime)
            .putInt(KEY_EXPIRES_IN, userResponse.expires_in)
            .apply()
    }
    
    // 兼容旧版方法
    fun saveUserLogin(context: Context, userId: String, username: String, token: String) {
        // 创建最小的UserResponse对象
        val userResponse = UserResponse(
            user_id = userId.toIntOrNull() ?: 0,
            username = username,
            nickname = username,
            token = token
        )
        saveUserLogin(context, userResponse)
    }
    
    // 获取Context的辅助方法
    private fun getContext(): Context? {
        return contextRef?.get()
    }

    fun isLoggedIn(): Boolean {
        val prefs: SharedPreferences = getContext()?.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE) ?: return false
        return prefs.getBoolean(KEY_IS_LOGGED_IN, false)
    }

    fun getUserId(): Int {
        val prefs: SharedPreferences = getContext()?.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE) ?: return 0
        return prefs.getInt(KEY_USER_ID, 0)
    }

    fun getUsername(): String? {
        val prefs: SharedPreferences = getContext()?.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE) ?: return null
        return prefs.getString(KEY_USERNAME, null)
    }
    
    fun getNickname(): String? {
        val prefs: SharedPreferences = getContext()?.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE) ?: return null
        return prefs.getString(KEY_NICKNAME, null)
    }
    
    fun getMobile(): String? {
        val prefs: SharedPreferences = getContext()?.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE) ?: return null
        return prefs.getString(KEY_MOBILE, null)
    }
    
    fun getAvatar(): String? {
        val prefs: SharedPreferences = getContext()?.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE) ?: return null
        return prefs.getString(KEY_AVATAR, null)
    }
    
    fun getScore(): Int {
        val prefs: SharedPreferences = getContext()?.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE) ?: return 0
        return prefs.getInt(KEY_SCORE, 0)
    }
    
    fun getToken(): String? {
        val prefs: SharedPreferences = getContext()?.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE) ?: return null
        return prefs.getString(KEY_TOKEN, null)
    }
    
    fun getExpireTime(): Long {
        val prefs: SharedPreferences = getContext()?.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE) ?: return 0
        return prefs.getLong(KEY_EXPIRETIME, 0)
    }

    fun logout() {
        val prefs: SharedPreferences = getContext()?.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE) ?: return
        prefs.edit().clear().apply()
    }
}
package com.sniper.arbademo.components.home

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.net.http.SslError
import android.os.Bundle
import android.util.Log
import android.webkit.CookieManager
import android.webkit.ConsoleMessage
//import android.webkit.SslError
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.graphics.Bitmap
import android.view.View
import android.webkit.WebResourceError
import android.widget.LinearLayout
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.sniper.arbademo.R
import com.sniper.arbademo.components.bridge.AndroidJavaScriptInterface
import com.sniper.arbademo.manager.PermissionManager
import com.sniper.arbademo.manager.UserManager

class WebActivity : AppCompatActivity(), AndroidJavaScriptInterface.OnCameraResultListener {
    private lateinit var webView: WebView
    private val TAG = "WebActivity"
    private var jsInterface: AndroidJavaScriptInterface? = null
    private lateinit var loadingContainer: LinearLayout
//   private val TARGET_URL = "http://192.168.3.49:5173"
//    private val TARGET_URL = "http://192.168.3.49:3000"
//    private val TARGET_URL = "http://192.168.130.128:5173/"
//     private val TARGET_URL = "http://192.168.3.49:5173"
      private val TARGET_URL = "https://client.handongnei.com"
//    private val TARGET_URL = "http://192.168.1.111:5173/"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_web)
        
        // 初始化WebView和loading视图
        webView = findViewById(R.id.webView)
        loadingContainer = findViewById(R.id.loadingContainer)
        setupWebView()
        
        // 检查登录状态并加载页面
        checkLoginStatusAndLoadPage()
        
        // 处理系统UI边缘
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        requestCameraPermission()
    }

    private fun requestCameraPermission() {
        PermissionManager.getInstance().requestPermission(this, Manifest.permission.CAMERA,
    object : PermissionManager.PermissionCallback {
        override fun onPermissionGranted(permissions: Array<String>) {
            // 权限授予，可以执行操作
            Log.d(TAG, "相机权限授予")
        }
        
        override fun onPermissionDenied(permissions: Array<String>) {
            // 权限被拒绝，处理拒绝逻辑
            Log.d(TAG, "相机权限被拒绝")
        }
    })
    }
    
    /**
     * 配置WebView设置
     */
    @SuppressLint("SetJavaScriptEnabled", "WebViewClientOnReceivedSslError")
    private fun setupWebView() {
        val webSettings = webView.settings
        // 启用JavaScript
        webSettings.javaScriptEnabled = true
        // 启用DOM存储API
        webSettings.domStorageEnabled = true
        // 设置缓存模式
        webSettings.cacheMode = WebSettings.LOAD_DEFAULT
        // 允许混合内容（HTTP和HTTPS）
        webSettings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        //
        webSettings.blockNetworkImage = false
        
        // 允许跨域访问
        webSettings.allowFileAccessFromFileURLs = true
        webSettings.allowUniversalAccessFromFileURLs = true
        
        // 添加JavaScript接口
//        webView.addJavascriptInterface(AndroidJavaScriptInterface(this, webView), "Android")
        // 创建并保存JavaScriptInterface引用
        jsInterface = AndroidJavaScriptInterface(this, webView)
        webView.addJavascriptInterface(jsInterface!!, "androidBridge")
        
        // 禁用第三方Cookie策略限制
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
        
        // 注入JavaScript来修改XMLHttpRequest，解决CORS问题
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                // 在WebView内部加载所有URL
                view.loadUrl(url)
                return true
            }
            
            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                // 显示loading视图
                loadingContainer.visibility = View.VISIBLE
                webView.visibility = View.INVISIBLE
            }
                
                override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                
                // 注入JavaScript代码来修改XMLHttpRequest，允许跨域请求
                val corsJs = """
                (function() {
                    var originalXhrOpen = XMLHttpRequest.prototype.open;
                    XMLHttpRequest.prototype.open = function(method, url, async, user, password) {
                        this.addEventListener('load', function() {
                            // 模拟CORS响应头
                            Object.defineProperty(this, 'responseHeaders', {
                                value: '${"Access-Control-Allow-Origin: *\nAccess-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS\nAccess-Control-Allow-Headers: *"}'
                            });
                        });
                        return originalXhrOpen.apply(this, arguments);
                    };
                })();
                """
                view.evaluateJavascript(corsJs, null)
                
                // 隐藏loading视图，显示WebView
                loadingContainer.visibility = View.GONE
                webView.visibility = View.VISIBLE
            }
                
                override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                super.onReceivedError(view, request, error)
                // 加载错误时也隐藏loading视图
                loadingContainer.visibility = View.GONE
                webView.visibility = View.VISIBLE
            }
            
            // 处理SSL错误（开发环境下允许所有SSL证书）
            override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
                // 注意：在生产环境中应该验证证书
                handler.proceed()
            }
        }
        
        // 设置WebChromeClient来处理JavaScript控制台日志
        webView.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(consoleMessage: ConsoleMessage): Boolean {
                Log.d("WebViewConsole", "${consoleMessage.message()} -- From line ${consoleMessage.lineNumber()} of ${consoleMessage.sourceId()}")
                return super.onConsoleMessage(consoleMessage)
            }
        }
    }
    
    /**
     * 检查登录状态并加载页面
     */
    private fun checkLoginStatusAndLoadPage() {
        // 检查用户是否已登录
        val isLoggedIn = UserManager.getToken() != null
        
        if (isLoggedIn) {
            // 登录成功，加载目标URL
            webView.loadUrl(TARGET_URL)
        } else {
            // 未登录，可以显示登录页面或加载默认页面
            // 这里简单地也加载目标URL，实际应用中可能需要重定向到登录页面
            webView.loadUrl(TARGET_URL)
        }
    }
    
    /**
     * 处理返回键，优先返回WebView的上一页
     */
    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
    
    override fun setJavaScriptInterface(jsInterface: AndroidJavaScriptInterface) {
        this.jsInterface = jsInterface
    }
    
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        
        // 将相机结果传递给JavaScriptInterface
        jsInterface?.handleCameraResult(resultCode, data)
    }
}
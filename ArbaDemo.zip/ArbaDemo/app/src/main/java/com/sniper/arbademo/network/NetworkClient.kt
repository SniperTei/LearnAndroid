package com.sniper.arbademo.network

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.HttpException

/**
 * 网络请求客户端
 */
object NetworkClient {
    private const val TAG = "NetworkClient"
    private val mainHandler = Handler(Looper.getMainLooper())

    /**
     * 初始化Retrofit
     * @param context 上下文
     */
    fun initRetrofit(context: Context) {
        RetrofitManager.init(context)
    }

    /**
     * 执行网络请求
     * @param request 网络请求函数
     * @param callback 回调接口
     */
    fun <T> request(request: suspend () -> BaseResponse<T>, callback: NetworkCallback<T>) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                // 执行网络请求
                val response = request()
                
                withContext(Dispatchers.Main) {
                    try {
                        if (response.isSuccess()) {
                            // 请求成功
                            response.data?.let { callback.onSuccess(it) }
                                ?: callback.onFailure(-1, "数据为空")
                        } else {
                            // 业务错误
                            callback.onFailure(response.code, response.msg)
                        }
                    } finally {
                        callback.onComplete()
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Network error: ${e.message}", e)
                
                // 处理异常
                val errorMsg = when (e) {
                    is HttpException -> "HTTP错误: ${e.code()}"
                    else -> "网络错误: ${e.message ?: "未知错误"}"
                }
                
                withContext(Dispatchers.Main) {
                    callback.onFailure(-1, errorMsg)
                    callback.onComplete()
                }
            }
        }
    }
}
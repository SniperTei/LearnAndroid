package com.sniper.arbademo.components.user

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.sniper.arbademo.R
import com.sniper.arbademo.base.activity.BaseActivity
import com.sniper.arbademo.components.camera.activity.CameraActivity
import com.sniper.arbademo.components.camera.manager.CameraManager
import com.sniper.arbademo.components.home.HomeActivity
import com.sniper.arbademo.components.home.WebActivity
import com.sniper.arbademo.components.user.viewmodel.LoginViewModel
import com.sniper.arbademo.components.user.viewmodel.LoginViewModel.LoginUiState
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class LoginActivity : BaseActivity() {
    private lateinit var etAccount: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnLogin: Button
    private lateinit var tvRegister: TextView
    private lateinit var progressBar: ProgressBar
    
    private lateinit var viewModel: LoginViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        // 初始化视图
        etAccount = findViewById(R.id.et_username) // 注意：这里保持原有的id，但变量名改为etAccount
        etPassword = findViewById(R.id.et_password)
        btnLogin = findViewById(R.id.btn_login)
        tvRegister = findViewById(R.id.tv_register)
        progressBar = findViewById(R.id.progress_bar) // 需要在布局文件中添加这个ProgressBar
        
        // 添加TextWatcher监听输入变化
        etAccount.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                s?.toString()?.let { account ->
                    // 当UI输入变化时，更新ViewModel中的状态
                    viewModel.updateLoginInput(account = account)
                }
            }
            
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        
        etPassword.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                s?.toString()?.let { password ->
                    // 当UI输入变化时，更新ViewModel中的状态
                    viewModel.updateLoginInput(password = password)
                }
            }
            
            override fun afterTextChanged(s: android.text.Editable?) {}
        })

        // 初始化ViewModel
        viewModel = ViewModelProvider(this)[LoginViewModel::class.java]
        
        // 初始化CameraManager，必须在onCreate中完成，确保在STARTED状态前注册ActivityResultLauncher
        CameraManager.getInstance().initialize(this)
        
        // 设置文本变化监听器，与ViewModel的loginInput状态同步
        setupTextWatchers()
        
        // 观察ViewModel的状态变化
        observeViewModel()

        // 设置登录按钮点击事件
        btnLogin.setOnClickListener {
            // 直接从ViewModel获取最新的输入状态
            val loginInput = viewModel.loginInput.value
            // 调用ViewModel进行登录
//            viewModel.login(this, loginInput.account.trim(), loginInput.password.trim())
            // 调试Camera 直接使用intent 跳转到CameraActivity
            startActivity(Intent(this, CameraActivity::class.java))
            
        }

        // 设置注册链接点击事件
        tvRegister.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
    }
    
    /**
     * 设置文本变化监听器
     */
    private fun setupTextWatchers() {
        // 账号输入框监听
        etAccount.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                s?.toString()?.let { account ->
                    // 当UI输入变化时，更新ViewModel中的状态
                    viewModel.updateLoginInput(account = account)
                }
            }
            
            override fun afterTextChanged(s: Editable?) {}
        })
        
        // 密码输入框监听
        etPassword.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                s?.toString()?.let { password ->
                    // 当UI输入变化时，更新ViewModel中的状态
                    viewModel.updateLoginInput(password = password)
                }
            }
            
            override fun afterTextChanged(s: Editable?) {}
        })
    }
    
    /**
     * 观察ViewModel的状态变化
     */
    private fun observeViewModel() {
        // 使用lifecycleScope和collectAsStateWithLifecycle观察UI状态
        lifecycleScope.launch {
            // 观察loginInput状态，用于数据绑定的反向更新
            viewModel.loginInput.collectLatest { loginInput ->
                // 避免不必要的UI更新导致的循环触发
                if (etAccount.text.toString() != loginInput.account) {
                    etAccount.setText(loginInput.account)
                }
                if (etPassword.text.toString() != loginInput.password) {
                    etPassword.setText(loginInput.password)
                }
            }
        }
        
        // 观察UI状态变化
        lifecycleScope.launch {
            viewModel.uiState.collect(::handleUiState)
        }
    }

    /**
     * 处理登录UI状态变化
     */
    private fun handleUiState(uiState: LoginViewModel.LoginUiState) {
        when (uiState) {
            is LoginViewModel.LoginUiState.Idle -> handleIdleState()
            is LoginViewModel.LoginUiState.Loading -> handleLoadingState()
            is LoginViewModel.LoginUiState.Success -> handleSuccessState()
            is LoginViewModel.LoginUiState.Error -> handleErrorState(uiState.message)
        }
    }

    /**
     * 处理初始状态
     */
    private fun handleIdleState() {
        progressBar.visibility = View.GONE
        btnLogin.isEnabled = true
    }

    /**
     * 处理加载中状态
     */
    private fun handleLoadingState() {
        progressBar.visibility = View.VISIBLE
        btnLogin.isEnabled = false
    }

    /**
     * 处理成功状态
     */
    private fun handleSuccessState() {
        progressBar.visibility = View.GONE
        btnLogin.isEnabled = true
        showToast("登录成功")
//        startActivity(Intent(this, HomeActivity::class.java))
        startActivity(Intent(this, WebActivity::class.java))
        finish()
    }

    /**
     * 处理错误状态
     */
    private fun handleErrorState(message: String) {
        progressBar.visibility = View.GONE
        btnLogin.isEnabled = true
        showToast(message)
    }
    
    override fun onDestroy() {
        super.onDestroy()
        // 重置UI状态，避免内存泄漏
        viewModel.resetUiState()
    }
    
    // 需要导入的包
    companion object {
        // 这里仅作为导入提示，实际代码中不需要此伴生对象
        // import androidx.lifecycle.lifecycleScope
        // import kotlinx.coroutines.launch
    }
}
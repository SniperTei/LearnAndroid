package com.sniper.arbademo.components.camera.activity

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.Environment
import android.util.DisplayMetrics
import android.util.Log
import android.util.Size
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.ImageView
import android.widget.Toast
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.sniper.arbademo.R
import com.sniper.arbademo.components.bridge.AndroidJavaScriptInterface
import com.sniper.arbademo.databinding.ActivityCameraBinding
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class CameraActivity : AppCompatActivity(), AndroidJavaScriptInterface.OnCameraResultListener {
    
    private var jsInterface: AndroidJavaScriptInterface? = null

    private val TAG = "CameraActivity"
    private val REQUEST_CAMERA_PERMISSION = 1001
    
    // 用于返回图片路径的key
    companion object {
        const val EXTRA_IMAGE_PATH = "extra_image_path"
    }

    private var _binding: ActivityCameraBinding? = null
    private val binding get() = _binding!!

    private var imageCapture: ImageCapture? = null
    private var cameraSelector: CameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
    private lateinit var cameraExecutor: ExecutorService

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // 先初始化布局
        _binding = ActivityCameraBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        // 设置全屏
        makeFullScreen()
        
        // 移除拍照轮廓图片（遮罩）


        // 初始化相机执行器
        cameraExecutor = Executors.newSingleThreadExecutor()

        // 设置按钮点击事件
        binding.btnCapture.setOnClickListener { takePhoto() }
        binding.btnBack.setOnClickListener { finish() }
        binding.btnSwitchCamera.setOnClickListener { switchCamera() }

        // 检查相机权限
        if (allPermissionsGranted()) {
            startCamera()
        } else {
            requestPermissions(
                arrayOf(Manifest.permission.CAMERA),
                REQUEST_CAMERA_PERMISSION
            )
        }
    }
    
    override fun setJavaScriptInterface(jsInterface: AndroidJavaScriptInterface) {
        this.jsInterface = jsInterface
    }
    
    // CameraActivity不需要onActivityResult方法，因为它是被调用的Activity，不是调用者

    private fun makeFullScreen() {
        // 隐藏状态栏和导航栏
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            window.insetsController?.apply {
                hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
            )
            @Suppress("DEPRECATION")
            supportActionBar?.hide()
        }
        
        // 防止拍照时自动亮屏
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)

        cameraProviderFuture.addListener({ 
            val cameraProvider: ProcessCameraProvider = cameraProviderFuture.get()
            
            // 计算预览视图的尺寸（考虑15%的遮挡条）
            val displayMetrics = DisplayMetrics()
            windowManager.defaultDisplay.getMetrics(displayMetrics)
            val screenWidth = displayMetrics.widthPixels
            val screenHeight = displayMetrics.heightPixels
            
            // 遮挡条的宽度和高度占屏幕的百分比（12%）
            val overlayPercent = 0.12f
            
            // 计算预览视图的实际尺寸
            val previewWidth = (screenWidth * (1 - 2 * overlayPercent)).toInt()
            val previewHeight = (screenHeight * (1 - 2 * overlayPercent)).toInt()

            // 设置预览，目标分辨率与预览视图一致
            val preview = Preview.Builder()
                .setTargetResolution(Size(previewWidth, previewHeight))
                .build()
                .also {
                    it.surfaceProvider = binding.previewView.surfaceProvider
                }

            // 设置图片捕获，目标分辨率与预览视图一致
            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .setTargetResolution(Size(previewWidth, previewHeight))
                .setTargetRotation(windowManager.defaultDisplay.rotation) // 设置照片旋转角度与设备方向一致
                .build()
                
            // 更新水印时间
//            updateWatermarkTime()

            try {
                // 解绑之前的所有相机
                cameraProvider.unbindAll()

                // 绑定相机
                cameraProvider.bindToLifecycle(
                    this,
                    cameraSelector,
                    preview,
                    imageCapture
                )

            } catch (e: Exception) {
                Log.e(TAG, "使用相机时出错: ${e.message}")
                Toast.makeText(this, "相机初始化失败", Toast.LENGTH_SHORT).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun takePhoto() {
        val imageCapture = imageCapture ?: return

        // 创建保存图片的文件
        val photoFile = File(
            getExternalFilesDir(Environment.DIRECTORY_PICTURES),
            "${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())}.jpg"
        )

        val outputOptions = ImageCapture.OutputFileOptions.Builder(photoFile).build()

        imageCapture.takePicture(
            outputOptions,
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                    Log.d(TAG, "拍照成功，图片路径: ${photoFile.absolutePath}")
                    // 使用系统方法压缩图片
//                    val compressedFile = compressImage(photoFile)
                    Toast.makeText(this@CameraActivity, "拍照成功", Toast.LENGTH_SHORT).show()
                    
                    // 返回图片路径给调用者
                    val resultIntent = Intent()
                    resultIntent.putExtra(EXTRA_IMAGE_PATH, photoFile.absolutePath)
                    setResult(RESULT_OK, resultIntent)
                    finish()
                }

                override fun onError(exception: ImageCaptureException) {
                    Log.e(TAG, "拍照失败: ${exception.message}")
                    Toast.makeText(this@CameraActivity, "拍照失败", Toast.LENGTH_SHORT).show()
                    setResult(RESULT_CANCELED)
                }
            }
        )
    }

    private fun switchCamera() {
        cameraSelector = if (cameraSelector == CameraSelector.DEFAULT_BACK_CAMERA) {
            CameraSelector.DEFAULT_FRONT_CAMERA
        } else {
            CameraSelector.DEFAULT_BACK_CAMERA
        }
        startCamera()
    }

    private fun allPermissionsGranted(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED
    }
    
    // 水印相关方法已移除以简化代码

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == REQUEST_CAMERA_PERMISSION) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startCamera()
            } else {
                Toast.makeText(this, "需要相机权限才能拍照", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        // 更新ImageCapture的旋转设置，确保照片方向与设备当前方向一致
        imageCapture?.setTargetRotation(windowManager.defaultDisplay.rotation)
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }
}
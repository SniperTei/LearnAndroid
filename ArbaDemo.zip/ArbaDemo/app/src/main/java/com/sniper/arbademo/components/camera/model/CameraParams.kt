package com.sniper.arbademo.components.camera.model

import android.net.Uri

/**
 * 相机参数配置类
 */
data class CameraParams(
    val cameraType: CameraType = CameraType.BACK, // 相机类型（前置/后置）
    val flashMode: FlashMode = FlashMode.OFF,    // 闪光灯模式
    val saveToGallery: Boolean = false,          // 是否保存到相册
    val maxWidth: Int? = null,                   // 最大宽度（可选）
    val maxHeight: Int? = null,                  // 最大高度（可选）
    val outputFormat: OutputFormat = OutputFormat.JPEG, // 输出格式
    val watermarkText: String? = null,           // 自定义水印文本，为null时使用默认水印（日期+时间+用户ID）
    val enableWatermark: Boolean = true          // 是否启用水印
)

/**
 * 相机类型枚举
 */
enum class CameraType {
    BACK,  // 后置相机
    FRONT  // 前置相机
}

/**
 * 闪光灯模式枚举
 */
enum class FlashMode {
    OFF,    // 关闭
    ON,     // 开启
    AUTO    // 自动
}

/**
 * 输出格式枚举
 */
enum class OutputFormat {
    JPEG,
    PNG,
    WEBP
}

/**
 * 相机结果类
 */
data class CameraResult(
    val imageUri: Uri,         // 图片URI
    val imagePath: String,     // 图片路径
    val imageWidth: Int,       // 图片宽度
    val imageHeight: Int,      // 图片高度
    val timestamp: Long        // 拍摄时间戳
)

/**
 * 相机状态密封类
 */
sealed class CameraState {
    object Idle : CameraState()                           // 空闲状态
    object Loading : CameraState()                        // 加载中
    data class Success(val result: CameraResult) : CameraState()  // 成功状态
    data class Error(val message: String) : CameraState() // 错误状态
    object Cancelled : CameraState()                      // 取消操作
}
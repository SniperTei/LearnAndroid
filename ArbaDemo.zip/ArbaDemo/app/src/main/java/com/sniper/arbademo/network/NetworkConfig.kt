package com.sniper.arbademo.network

/**
 * 网络配置常量
 */
object NetworkConfig {
    // 基础URL
    const val BASE_URL = "http://156.226.180.172"
    
    // 连接超时时间（毫秒）
    const val CONNECT_TIMEOUT = 180000L
    
    // 读取超时时间（毫秒）
    const val READ_TIMEOUT = 180000L
    
    // 写入超时时间（毫秒）
    const val WRITE_TIMEOUT = 180000L
    
    // 是否显示日志（调试模式）
    const val SHOW_LOG = true
}
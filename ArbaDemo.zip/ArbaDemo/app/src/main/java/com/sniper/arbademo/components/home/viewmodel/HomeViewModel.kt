package com.sniper.arbademo.components.home.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sniper.arbademo.manager.UserManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * HomeActivity的ViewModel，负责管理首页用户信息的状态
 */
class HomeViewModel : ViewModel() {

    // 用户信息状态 - 使用StateFlow替代LiveData
    private val _userInfoState = MutableStateFlow<UserInfoUiState>(UserInfoUiState.Loading)
    val userInfoState: StateFlow<UserInfoUiState> = _userInfoState.asStateFlow()

    /**
     * 用户信息UI状态密封类
     */
    sealed class UserInfoUiState {
        object Loading : UserInfoUiState()
        data class Success(val nickname: String, val avatarUrl: String?) : UserInfoUiState()
        data class Error(val message: String) : UserInfoUiState()
    }

    /**
     * 加载用户信息
     * @param context Android上下文对象
     */
    fun loadUserInfo(context: android.content.Context) {
        viewModelScope.launch {
            _userInfoState.value = UserInfoUiState.Loading
            
            try {
                // 从UserManager获取用户信息
                val username = UserManager.getNickname()
                val avatarUrl = UserManager.getAvatar()
                
                if (username != null) {
                    _userInfoState.value = UserInfoUiState.Success(username, avatarUrl)
                } else {
                    _userInfoState.value = UserInfoUiState.Error("用户信息未找到")
                }
            } catch (e: Exception) {
                _userInfoState.value = UserInfoUiState.Error("加载用户信息失败: \${e.message}")
            }
        }
    }
}
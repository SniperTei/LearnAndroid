package com.sniper.arbademo.components.home.model

import android.os.Parcel
import android.os.Parcelable
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 物品数据模型
 * 对应后端返回的物品信息结构
 */
data class Item(
    val id: Int? = null,                     // 物品ID
    val name: String? = null,                // 物品名称
    val content: String? = null,             // 物品描述
    val itemimage: String? = "",             // 物品图片路径
    val createtime: Long? = null,            // 创建时间戳
    val updatetime: Long? = null,            // 更新时间戳
    val file_name: String? = null            // 文件名称（图片URL）
) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readValue(Int::class.java.classLoader) as? Int,
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readValue(Long::class.java.classLoader) as? Long,
        parcel.readValue(Long::class.java.classLoader) as? Long,
        parcel.readString()
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeValue(id)
        parcel.writeString(name)
        parcel.writeString(content)
        parcel.writeString(itemimage)
        parcel.writeValue(createtime)
        parcel.writeValue(updatetime)
        parcel.writeString(file_name)
    }

    override fun describeContents(): Int {
        return 0
    }

    /**
     * 获取格式化的创建时间
     */
    fun getFormattedCreateTime(): String {
        return createtime?.let {
            try {
                val date = Date(it * 1000) // 假设后端返回的是秒级时间戳
                val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                sdf.format(date)
            } catch (e: Exception) {
                ""
            }
        } ?: ""
    }

    companion object CREATOR : Parcelable.Creator<Item> {
        override fun createFromParcel(parcel: Parcel): Item {
            return Item(parcel)
        }

        override fun newArray(size: Int): Array<Item?> {
            return arrayOfNulls(size)
        }
    }
}

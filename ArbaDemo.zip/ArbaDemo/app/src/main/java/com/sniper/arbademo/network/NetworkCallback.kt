package com.sniper.arbademo.network

/**
 * 网络请求回调接口
 * @param T 响应数据类型
 */
interface NetworkCallback<T> {
    /**
     * 请求成功回调
     * @param data 响应数据
     */
    fun onSuccess(data: T)
    
    /**
     * 请求失败回调
     * @param errorCode 错误码
     * @param errorMsg 错误信息
     */
    fun onFailure(errorCode: Int, errorMsg: String)
    
    /**
     * 请求完成回调（无论成功或失败都会调用）
     */
    fun onComplete()
}
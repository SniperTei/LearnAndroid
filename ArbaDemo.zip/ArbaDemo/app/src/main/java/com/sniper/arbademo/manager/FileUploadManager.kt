package com.sniper.arbademo.manager

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.util.Log
import com.sniper.arbademo.network.NetworkCallback
import com.sniper.arbademo.network.NetworkClient
import com.sniper.arbademo.network.RetrofitManager
import com.sniper.arbademo.network.api.ApiService
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import retrofit2.Response
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.logging.HttpLoggingInterceptor
import java.io.File
import java.io.FileOutputStream
import java.math.BigInteger
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.util.concurrent.Executors

/**
 * 文件上传管理器，支持多种文件类型的选择和上传
 * 上传路径格式: http://156.226.180.172/uploads/上传当天的日期/文件类型(IMG_/VIDEO_/FILE_md5加密.后缀)
 */
object FileUploadManager {
    private const val TAG = "FileUploadManager"
    const val REQUEST_CODE_PICK_FILE = 1001
    
    /**
     * 打开文件选择器，支持多种文件类型
     * @param activity 当前Activity
     * @param mimeTypes 可选的MIME类型过滤，null表示允许所有类型
     */
    fun pickFile(activity: Activity, mimeTypes: Array<String>? = null) {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        
        if (mimeTypes != null && mimeTypes.isNotEmpty()) {
            // 设置MIME类型过滤
            intent.type = "*/*"
            intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes)
        } else {
            // 默认允许所有类型
            intent.type = "*/*"
        }
        
        activity.startActivityForResult(intent, REQUEST_CODE_PICK_FILE)
    }
    
    /**
     * 打开特定类型文件选择器
     */
    fun pickImage(activity: Activity) {
        pickFile(activity, arrayOf("image/*"))
    }
    
    fun pickVideo(activity: Activity) {
        pickFile(activity, arrayOf("video/*"))
    }
    
    fun pickDocument(activity: Activity) {
        pickFile(activity, arrayOf(
            "text/plain",           // .txt
            "application/json",     // .json
            "application/msword",   // .doc
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document", // .docx
            "application/vnd.ms-excel", // .xls
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", // .xlsx
            "application/pdf"       // .pdf
        ))
    }
    
    /**
     * 处理文件选择结果
     * @param context 上下文
     * @param data Intent数据
     * @return 选中的文件，如果选择失败返回null
     */
    fun handleFileResult(context: Context, data: Intent?): File? {
        if (data == null || data.data == null) {
            Log.e(TAG, "文件选择失败: 没有选择文件")
            return null
        }
        
        return try {
            val uri = data.data!!
            val file = uriToFile(context, uri)
            Log.d(TAG, "文件选择成功: ${file.absolutePath}")
            file
        } catch (e: Exception) {
            Log.e(TAG, "文件选择失败: ${e.message}")
            null
        }
    }
    
    /**
     * 将Uri转换为File
     * @param context 上下文
     * @param uri 文件Uri
     * @return 转换后的文件
     */
    private fun uriToFile(context: Context, uri: Uri): File {
        // 获取文件扩展名
        val extension = getFileExtensionFromUri(context, uri)
        // 生成临时文件名
        val tempFileName = "temp_${System.currentTimeMillis()}${extension}"
        val file = File(context.cacheDir, tempFileName)
        
        context.contentResolver.openInputStream(uri)?.use { inputStream ->
            FileOutputStream(file).use { outputStream ->
                val buffer = ByteArray(4 * 1024)
                var read: Int
                while (inputStream.read(buffer).also { read = it } != -1) {
                    outputStream.write(buffer, 0, read)
                }
                outputStream.flush()
            }
        }
        
        return file
    }
    
    /**
     * 获取文件扩展名
     */
    private fun getFileExtensionFromUri(context: Context, uri: Uri): String {
        val mimeType = context.contentResolver.getType(uri)
        if (mimeType != null) {
            // MIME类型到扩展名的映射
            val extensionMap = mapOf(
                "image/jpeg" to ".jpg",
                "image/png" to ".png",
                "image/gif" to ".gif",
                "text/plain" to ".txt",
                "application/json" to ".json",
                "application/pdf" to ".pdf",
                "application/msword" to ".doc",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document" to ".docx",
                "application/vnd.ms-excel" to ".xls",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" to ".xlsx",
                "video/mp4" to ".mp4",
                "video/avi" to ".avi"
            )
            extensionMap[mimeType]?.let { return it }
        }
        return ".bin"
    }
    
    /**
     * 上传文件
     * @param file 要上传的文件
     * @param callback 上传结果回调
     */
    fun uploadFile(file: File, callback: NetworkCallback<String>) {
        // 检查文件是否存在
        if (!file.exists() || !file.isFile) {
            callback.onFailure(-1, "文件不存在或不是有效文件")
            callback.onComplete()
            return
        }
        
        // 检查文件大小（可选）
        val maxFileSize = 10 * 1024 * 1024 // 10MB
        if (file.length() > maxFileSize) {
            callback.onFailure(-1, "文件大小超过限制（最大${maxFileSize/1024/1024}MB）")
            callback.onComplete()
            return
        }
        
        // 使用协程处理上传任务
        GlobalScope.launch(Dispatchers.IO) {
            try {
                // 根据文件扩展名确定MIME类型
                val mimeType = getMimeTypeFromFile(file)
                
                // 生成符合要求的文件名格式：文件类型(IMG_/VIDEO_/FILE_md5加密.后缀)
                val fileTypePrefix = getFileTypePrefix(mimeType)
                val fileExtension = ".${file.extension}"
                val fileMd5 = calculateFileMd5(file)
                val formattedFileName = "${fileTypePrefix}${fileMd5}${fileExtension}"
                
                // 创建请求体
                val requestBody = file.asRequestBody(mimeType.toMediaTypeOrNull())
                val filePart = MultipartBody.Part.createFormData("file", formattedFileName, requestBody)
                
                Log.d(TAG, "准备上传文件: $formattedFileName, MIME类型: $mimeType")
                
                // 使用Retrofit调用上传接口
                val apiService = RetrofitManager.getApiService()
                val response = apiService.uploadFile(filePart)
                
                // 使用BaseResponse的isSuccess方法判断上传是否成功
                if (response.isSuccess()) {
                    // 上传成功，从data中提取fullurl
                    val data = response.data as? Map<String, Any>
                    val fullUrl = data?.get("fullurl") as? String
                    val url = data?.get("url") as? String
                    
                    Log.d(TAG, "上传响应数据 - fullurl: $fullUrl, url: $url")
                    
                    if (url != null) {
                        Log.d(TAG, "文件上传成功，获取URL: $url")
                        callback.onSuccess(url)
                    } else {
                        Log.e(TAG, "文件上传成功，但未获取到完整URL字段")
                        callback.onFailure(-1, "获取URL失败")
                    }
                } else {
                    Log.e(TAG, "文件上传失败: 错误码=${response.code}, 错误信息=${response.msg}")
                    callback.onFailure(response.code, response.msg)
                }
            } catch (e: Exception) {
                Log.e(TAG, "文件上传异常: ${e.message}", e)
                callback.onFailure(-1, "上传失败: ${e.message}")
            } finally {
                callback.onComplete()
            }
        }
    }
    
    /**
     * 根据文件MIME类型获取文件前缀
     */
    private fun getFileTypePrefix(mimeType: String): String {
        return when {
            mimeType.startsWith("image/") -> "IMG_"
            mimeType.startsWith("video/") -> "VIDEO_"
            else -> "FILE_"
        }
    }
    
    /**
     * 根据文件扩展名获取MIME类型
     */
    private fun getMimeTypeFromFile(file: File): String {
        val extension = file.extension.lowercase()
        return when (extension) {
            "jpg", "jpeg" -> "image/jpeg"
            "png" -> "image/png"
            "gif" -> "image/gif"
            "txt" -> "text/plain"
            "json" -> "application/json"
            "pdf" -> "application/pdf"
            "doc" -> "application/msword"
            "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            "xls" -> "application/vnd.ms-excel"
            "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            "mp4" -> "video/mp4"
            "avi" -> "video/avi"
            else -> "application/octet-stream"
        }
    }
    
    /**
     * 计算文件的MD5值
     */
    private fun calculateFileMd5(file: File): String {
        return try {
            val md = MessageDigest.getInstance("MD5")
            file.inputStream().use { input ->
                val buffer = ByteArray(4096)
                var bytesRead: Int
                while (input.read(buffer).also { bytesRead = it } != -1) {
                    md.update(buffer, 0, bytesRead)
                }
            }
            val hashBytes = md.digest()
            // 转换为十六进制字符串
            BigInteger(1, hashBytes).toString(16).padStart(32, '0')
        } catch (e: Exception) {
            Log.e(TAG, "计算文件MD5失败: ${e.message}")
            // 如果计算失败，使用时间戳作为备选
            System.currentTimeMillis().toString()
        }
    }
}
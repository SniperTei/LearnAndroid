package com.sniper.arbademo

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.sniper.arbademo.components.home.HomeActivity
import com.sniper.arbademo.components.user.LoginActivity
import com.sniper.arbademo.components.home.WebActivity
import com.sniper.arbademo.manager.UserManager
import com.sniper.arbademo.network.NetworkClient

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // 初始化Retrofit
        initRetrofit()
        startActivity(Intent(this, WebActivity::class.java))
        // 检查用户是否已登录
//        if (UserManager.isLoggedIn()) {
            // 已登录，跳转到首页（使用带有底部Tab的主界面）
            // startActivity(Intent(this, HomeActivity::class.java))
             startActivity(Intent(this, WebActivity::class.java))
//        } else {
//            // 未登录，跳转到登录页面
//           startActivity(Intent(this, LoginActivity::class.java))
//        }
        
        // 结束当前Activity
        finish()
    }

    // 初始化Retrofit
    private fun initRetrofit() {
        NetworkClient.initRetrofit(this)
    }
}

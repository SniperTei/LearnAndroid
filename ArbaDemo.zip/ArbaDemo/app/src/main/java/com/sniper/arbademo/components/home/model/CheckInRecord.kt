package com.sniper.arbademo.components.home.model

/**
 * 用户信息子模型
 * 对应JSON中的user对象
 */
data class CheckInRecordUserInfo(
    val avatar: String,
    val bio: String,
    val birthday: Long?,
    val createtime: Long,
    val email: String,
    val gender: Int,
    val group_id: Int,
    val id: Int,
    val joinip: String,
    val jointime: Long,
    val jointime_text: String,
    val level: Int,
    val loginfailure: Int,
    val loginfailuretime: Long?,
    val loginip: String,
    val logintime: Long,
    val logintime_text: String,
    val maxsuccessions: Int,
    val mobile: String,
    val money: String,
    val nickname: String,
    val password: String,
    val prevtime: Long,
    val prevtime_text: String,
    val salt: String,
    val score: Int,
    val status: String,
    val successions: Int,
    val token: String,
    val updatetime: Long,
    val username: String,
    val verification: String
)

/**
 * 打卡记录数据模型
 * 对应后端返回的打卡记录信息结构
 */
data class CheckInRecord(
    val admin_id: Int,
    val admintime: Long?,
    val createtime: Long,
    val id: Int,
    val items_id: Int,
    val itemsimage: String?,
    var score: Int,
    val updatetime: Long,
    val user: CheckInRecordUserInfo,
    val user_id: Int
)

/**
 * 打卡记录列表数据模型
 * 对应后端返回的打卡记录列表结构
 */
data class CheckInRecordListData(
    val rows: List<CheckInRecord>? = null,
    val total: Int = 0,
    val page: Int = 1
)

/**
 * 为CheckInRecord添加扩展方法
 */
fun CheckInRecord.getFormattedTime(): String {
    return try {
        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault())
        sdf.format(java.util.Date(createtime * 1000))
    } catch (e: Exception) {
        "时间未知"
    }
}

fun CheckInRecord.getUsername(): String {
    return user?.username ?: "未知用户"
}

fun CheckInRecord.getNickname(): String {
    return user?.nickname ?: "未知用户"
}

fun CheckInRecord.getStatus(): String {
    return when (score) {
        0 -> "待审核"
        else -> "已评分"
    }
}

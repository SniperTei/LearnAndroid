package com.sniper.arbademo.components.home.model
import com.sniper.arbademo.components.home.model.Item

/**
 * 物品列表数据
 */
data class ItemListData(
    val rows: List<Item>? = null,
    val total: Int = 0,
    val page: Int = 1
)

/**
 * 物品模型 - 已在Item.kt中定义，此处保留注释以便参考
 */
//data class Item(
//    val id: Int = 0,
//    val name: String = "",
//    val content: String = "",
//    val itemimage: String = "",
//    val createtime: Long = 0,
//    val updatetime: Long = 0
//)
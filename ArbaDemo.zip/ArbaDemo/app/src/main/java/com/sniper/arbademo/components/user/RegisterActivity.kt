package com.sniper.arbademo.components.user

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.ProgressBar
import androidx.activity.enableEdgeToEdge
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.ViewModelProvider
import com.sniper.arbademo.R
import com.sniper.arbademo.base.activity.BaseActivity
import com.sniper.arbademo.components.home.HomeActivity
import com.sniper.arbademo.components.user.LoginActivity
import com.sniper.arbademo.components.user.viewmodel.RegisterViewModel
import com.sniper.arbademo.manager.UserManager

class RegisterActivity : BaseActivity() {
    private lateinit var etUsername: EditText
    private lateinit var etPassword: EditText
    private lateinit var etConfirmPassword: EditText
    private lateinit var btnRegister: Button
    private lateinit var tvLogin: TextView
    private lateinit var progressBar: ProgressBar
    
    private lateinit var viewModel: RegisterViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        // 初始化视图
        initViews()
        
        // 初始化ViewModel
        viewModel = ViewModelProvider(this).get(RegisterViewModel::class.java)
        
        // 观察ViewModel中的数据变化
        observeViewModel()
        
        // 设置事件监听
        setupListeners()
        
        // 处理系统栏适配
        handleSystemBars()
    }
    
    private fun initViews() {
        etUsername = findViewById(R.id.et_username)
        etPassword = findViewById(R.id.et_password)
        etConfirmPassword = findViewById(R.id.et_confirm_password)
        btnRegister = findViewById(R.id.btn_register)
        tvLogin = findViewById(R.id.tv_login)
        progressBar = findViewById(R.id.progress_bar) // 假设布局中有这个ProgressBar
    }
    
    private fun observeViewModel() {
        // 观察注册状态
        viewModel.isRegistering.observe(this) { isRegistering ->
            // 显示/隐藏进度条
            progressBar.visibility = if (isRegistering) android.view.View.VISIBLE else android.view.View.GONE
            // 启用/禁用注册按钮
            btnRegister.isEnabled = !isRegistering
        }
        
        // 观察注册结果
        viewModel.registerSuccess.observe(this) { isSuccess ->
            if (isSuccess) {
                showToast("注册成功")
                // 注册成功后，自动登录并跳转到首页
                val username = etUsername.text.toString().trim()
                UserManager.saveUserLogin(this, System.currentTimeMillis().toString(), username, "token_mock")
                startActivity(Intent(this, HomeActivity::class.java))
                finish()
            }
        }
        
        // 观察错误信息
        viewModel.errorMessage.observe(this) { errorMessage ->
            if (!errorMessage.isNullOrEmpty()) {
                showToast(errorMessage)
            }
        }
    }
    
    private fun setupListeners() {
        // 设置注册按钮点击事件
        btnRegister.setOnClickListener {
            viewModel.clearErrorMessage()
            val username = etUsername.text.toString().trim()
            val password = etPassword.text.toString().trim()
            val confirmPassword = etConfirmPassword.text.toString().trim()
            viewModel.register(username, password, confirmPassword)
        }
        
        // 设置去登录链接点击事件
        tvLogin.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }
    
    private fun handleSystemBars() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}
package com.sniper.arbademo.components.user.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import android.content.Context
import com.sniper.arbademo.components.user.model.UserResponse
import com.sniper.arbademo.components.user.repository.RegisterRepository
import com.sniper.arbademo.manager.UserManager
import com.sniper.arbademo.network.NetworkCallback

/**
 * 注册ViewModel
 */
class RegisterViewModel : ViewModel() {
    // 注册状态
    private val _isRegistering = MutableLiveData(false)
    val isRegistering: LiveData<Boolean> = _isRegistering
    
    // 注册结果
    private val _registerSuccess = MutableLiveData(false)
    val registerSuccess: LiveData<Boolean> = _registerSuccess
    
    // 错误信息
    private val _errorMessage = MutableLiveData<String?>(null)
    val errorMessage: LiveData<String?> = _errorMessage
    
    private val repository = RegisterRepository()
    
    /**
     * 处理注册
     */
    fun register(context: Context, username: String, password: String, confirmPassword: String) {
        // 输入验证
        val validationError = validateInput(username, password, confirmPassword)
        if (validationError != null) {
            _errorMessage.value = validationError
            return
        }
        
        // 开始注册
        _isRegistering.value = true
        _errorMessage.value = null
        
        // 调用仓库层进行注册
        repository.register(username, password, confirmPassword, object : NetworkCallback<UserResponse> {
            override fun onSuccess(data: UserResponse) {
                // 保存用户信息
                UserManager.saveUserLogin(context, data)
                _registerSuccess.value = true
                _isRegistering.value = false
            }
            
            override fun onFailure(errorCode: Int, errorMsg: String) {
                _errorMessage.value = errorMsg
                _registerSuccess.value = false
                _isRegistering.value = false
            }
            
            override fun onComplete() {
                // 已经在onSuccess和onFailure中处理了状态更新
            }
        })
    }
    
    // 兼容旧版方法，不传入Context时使用
    fun register(username: String, password: String, confirmPassword: String) {
        _errorMessage.value = "注册功能需要Context参数"
    }
    
    /**
     * 验证输入
     */
    private fun validateInput(username: String, password: String, confirmPassword: String): String? {
        if (username.isEmpty()) {
            return "请输入用户名"
        }
        
        if (password.isEmpty()) {
            return "请输入密码"
        }
        
        if (password.length < 6) {
            return "密码长度不能少于6位"
        }
        
        if (password != confirmPassword) {
            return "两次输入的密码不一致"
        }
        
        return null
    }
    
    /**
     * 清除错误信息
     */
    fun clearErrorMessage() {
        _errorMessage.value = null
    }
}
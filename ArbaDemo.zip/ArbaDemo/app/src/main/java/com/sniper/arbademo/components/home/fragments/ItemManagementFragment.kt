package com.sniper.arbademo.components.home.fragments

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.sniper.arbademo.R
import com.sniper.arbademo.base.fragment.BaseFragment
import com.sniper.arbademo.components.home.model.Item
import com.sniper.arbademo.components.home.viewmodel.ItemManagementViewModel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import androidx.lifecycle.lifecycleScope
import coil3.load
import com.sniper.arbademo.components.home.model.ItemListData
import com.sniper.arbademo.databinding.FragmentItemManagementBinding
import com.sniper.arbademo.network.NetworkConfig

class ItemManagementFragment : BaseFragment() {
    private lateinit var viewModel: ItemManagementViewModel
    private var _binding: FragmentItemManagementBinding? = null
    private val binding get() = _binding!!
    
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentItemManagementBinding.inflate(inflater, container, false)
        
        // 设置RecyclerView
        binding.recyclerViewItems.layoutManager = LinearLayoutManager(requireContext())
        
        // 初始化ViewModel
        viewModel = ViewModelProvider(this)[ItemManagementViewModel::class.java]
        
        // 设置点击事件
        binding.btnAddItem.setOnClickListener {
            navigateToItemDetail(null) // 新增模式，不传Item
        }
        
        // 观察ViewModel状态
        observeViewModel()
        
        // 加载物品列表
        viewModel.loadItems()
        
        return binding.root
    }
    
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
    
    private fun observeViewModel() {
        // 观察物品列表状态
        lifecycleScope.launch {
            viewModel.itemsState.collectLatest { state ->
                when (state) {
                    is ItemManagementViewModel.ItemsUiState.Idle -> {
                        // 初始状态，不做处理
                    }
                    is ItemManagementViewModel.ItemsUiState.Loading -> {
                        showLoading()
                    }
                    is ItemManagementViewModel.ItemsUiState.Success -> {
                        showItems(state.items)
                    }
                    is ItemManagementViewModel.ItemsUiState.Error -> {
                        showError(state.message)
                    }
                }
            }
        }
    }
    
    private fun showLoading() {
        binding.progressBar.visibility = View.VISIBLE
        binding.recyclerViewItems.visibility = View.GONE
        binding.emptyView.visibility = View.GONE
    }
    
    private fun showItems(items: ItemListData) {
        binding.progressBar.visibility = View.GONE
        
        if (items.total == 0) {
            binding.recyclerViewItems.visibility = View.GONE
            binding.emptyView.visibility = View.VISIBLE
        } else {
            binding.recyclerViewItems.visibility = View.VISIBLE
            binding.emptyView.visibility = View.GONE
            // 由于total不为0时list一定有值，使用!!操作符
            binding.recyclerViewItems.adapter = ItemAdapter(items.rows!!)
        }
    }
    
    private fun showError(message: String) {
        binding.progressBar.visibility = View.GONE
        binding.recyclerViewItems.visibility = View.GONE
        binding.emptyView.visibility = View.VISIBLE
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
    }

    /**
     * 跳转到物品详情页
     * @param item 要编辑的物品对象，为null表示新增模式
     */
    private fun navigateToItemDetail(item: Item? = null) {
        val detailFragment = ItemMgmtDetailFragment.newInstance(item)
        parentFragmentManager.beginTransaction()
            .replace(id, detailFragment) // 使用当前Fragment的id作为容器
            .addToBackStack(null)
            .commit()
    }
    
    /**
     * 物品列表适配器
     */
    private inner class ItemAdapter(private val items: List<Item>) : 
        RecyclerView.Adapter<ItemAdapter.ItemViewHolder>() {
        
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_item_management, parent, false)
            return ItemViewHolder(view)
        }
        
        override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
            val item = items[position]
            holder.bind(item)
        }
        
        override fun getItemCount(): Int = items.size
        
        inner class ItemViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            private val tvItemName: TextView = itemView.findViewById(R.id.tv_item_name)
            private val tvItemContent: TextView = itemView.findViewById(R.id.tv_item_content)
            private val ivItemImage: ImageView = itemView.findViewById(R.id.iv_item_image)
            
            fun bind(item: Item) {
                tvItemName.text = item.name
                tvItemContent.text = item.content
                
                // 加载图片（如果有图片URL）
               if (item.itemimage?.isNotEmpty() == true) {
                   val imageUrl = "${NetworkConfig.BASE_URL}${item.itemimage}"
                   ivItemImage.load(imageUrl)
               }
                
                // 设置列表项点击事件
                itemView.setOnClickListener {
                    // 编辑模式，传递Item对象
                    navigateToItemDetail(item)
                }
            }
        }
    }
    

}
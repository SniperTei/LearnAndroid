package com.sniper.arbademo.components.home

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.sniper.arbademo.R
import com.sniper.arbademo.base.activity.BaseActivity
import com.sniper.arbademo.components.home.fragments.ItemManagementFragment
import com.sniper.arbademo.components.home.fragments.CheckInFragment
import com.sniper.arbademo.components.home.fragments.CheckInRecordFragment
import com.sniper.arbademo.components.home.fragments.StatisticsFragment
import com.sniper.arbademo.components.home.fragments.SettingsFragment
import com.sniper.arbademo.components.home.viewmodel.HomeViewModel
import com.sniper.arbademo.components.user.LoginActivity
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

class HomeActivity : BaseActivity(), View.OnClickListener {
    private lateinit var menuItemManagement: TextView
    private lateinit var menuCheckIn: TextView
    private lateinit var menuCheckInRecord: TextView
    private lateinit var menuStatistics: TextView
    private lateinit var menuSettings: TextView
    
    // 用户信息UI组件
    private lateinit var ivUserAvatar: ImageView
    private lateinit var tvUserNickname: TextView
    private lateinit var btnLogout: Button
    
    // ViewModel
    private lateinit var viewModel: HomeViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        // 初始化菜单视图
        menuItemManagement = findViewById(R.id.menu_item_management)
        menuCheckIn = findViewById(R.id.menu_check_in)
        menuCheckInRecord = findViewById(R.id.menu_check_in_record)

        menuStatistics = findViewById(R.id.menu_statistics)
        menuSettings = findViewById(R.id.menu_settings)
        
        // 初始化用户信息UI组件
        ivUserAvatar = findViewById(R.id.iv_user_avatar)
        tvUserNickname = findViewById(R.id.tv_user_nickname)
        btnLogout = findViewById(R.id.btn_logout)
        setupLogoutButton()

        // 设置点击监听
        menuItemManagement.setOnClickListener(this)
        menuCheckIn.setOnClickListener(this)
        menuCheckInRecord.setOnClickListener(this)
        menuStatistics.setOnClickListener(this)
        menuSettings.setOnClickListener(this)
        
        // 初始化ViewModel
        viewModel = ViewModelProvider(this)[HomeViewModel::class.java]
        
        // 观察ViewModel的状态变化
        observeViewModel()
        
        // 加载用户信息
        viewModel.loadUserInfo(this)

        // 默认显示物品管理页面
        showFragment(ItemManagementFragment())
        setSelectedMenuItem(menuItemManagement)
    }
    
    // 设置退出按钮点击事件
    private fun setupLogoutButton() {
        btnLogout.setOnClickListener {
            showLogoutConfirmDialog()
        }
    }

    // 显示退出确认对话框
    private fun showLogoutConfirmDialog() {
        AlertDialog.Builder(this)
            .setTitle("退出登录")
            .setMessage("确定要退出当前账号吗？")
            .setPositiveButton("确定") { _, _ ->
                performLogout()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    // 执行退出登录操作
    private fun performLogout() {
        // 这里可以添加清除用户数据的逻辑
        // 例如清除UserManager中的用户信息
        
        // 启动登录页面并结束当前活动
        val intent = Intent(this, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }

    /**
     * 观察ViewModel的状态变化
     */
    private fun observeViewModel() {
        lifecycleScope.launch {
            viewModel.userInfoState.collect { uiState ->
                when (uiState) {
                    is HomeViewModel.UserInfoUiState.Loading -> {
                        // 加载中状态，可以显示加载指示器
                    }
                    is HomeViewModel.UserInfoUiState.Success -> {
                        // 显示用户信息
                        tvUserNickname.text = uiState.nickname
                        // 这里可以添加加载头像的逻辑
                        if (!uiState.avatarUrl.isNullOrEmpty()) {
                            // 使用图片加载库加载头像，例如Glide
                            // Glide.with(this@HomeActivity).load(uiState.avatarUrl).into(ivUserAvatar)
                        }
                    }
                    is HomeViewModel.UserInfoUiState.Error -> {
                        // 显示错误信息
                        tvUserNickname.text = uiState.message
                    }
                }
            }
        }
    }

    override fun onClick(v: View) {
        // 重置所有菜单项样式
        resetMenuItems()

        // 根据点击的菜单项切换页面
        when (v.id) {
            R.id.menu_item_management -> {
                showFragment(ItemManagementFragment())
                setSelectedMenuItem(menuItemManagement)
            }
            R.id.menu_check_in -> {
                showFragment(CheckInFragment())
                setSelectedMenuItem(menuCheckIn)
            }
            R.id.menu_check_in_record -> {
                showFragment(CheckInRecordFragment())
                setSelectedMenuItem(menuCheckInRecord)
            }
            R.id.menu_statistics -> {
                showFragment(StatisticsFragment())
                setSelectedMenuItem(menuStatistics)
            }
            R.id.menu_settings -> {
                showFragment(SettingsFragment())
                setSelectedMenuItem(menuSettings)
            }
        }
    }

    // 显示指定的Fragment
    private fun showFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.content_container, fragment)
            .commit()
    }

    // 设置选中菜单项的样式
    private fun setSelectedMenuItem(menuItem: TextView) {
        menuItem.setBackgroundColor(resources.getColor(android.R.color.holo_blue_light))
        menuItem.setTextColor(resources.getColor(android.R.color.white))
    }

    // 重置所有菜单项样式
    private fun resetMenuItems() {
        val menuItems = listOf(menuItemManagement, menuCheckIn, menuCheckInRecord, menuStatistics, menuSettings)
        for (item in menuItems) {
            item.setBackgroundColor(resources.getColor(android.R.color.transparent))
            item.setTextColor(resources.getColor(android.R.color.black))
        }
    }
}
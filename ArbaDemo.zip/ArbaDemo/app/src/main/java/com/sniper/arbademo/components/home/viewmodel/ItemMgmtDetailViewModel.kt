package com.sniper.arbademo.components.home.viewmodel

import android.net.Uri
import android.util.Log
import androidx.lifecycle.LiveData
import android.os.Handler
import android.os.Looper
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.sniper.arbademo.components.home.model.Item
import com.sniper.arbademo.components.home.repository.ItemRepository
import com.sniper.arbademo.manager.FileUploadManager
import com.sniper.arbademo.network.NetworkCallback
import java.io.File

class ItemMgmtDetailViewModel : ViewModel() {
    // 状态数据
    private val _isLoading = MutableLiveData(false)
    val isLoading: LiveData<Boolean> = _isLoading
    
    private val _errorMessage = MutableLiveData<String?>(null)
    val errorMessage: LiveData<String?> = _errorMessage
    
    private val _imageUrl = MutableLiveData<String?>(null)
    val imageUrl: LiveData<String?> = _imageUrl
    
    private val _imageUri = MutableLiveData<Uri?>(null)
    val imageUri: LiveData<Uri?> = _imageUri
    
    private val _submitSuccess = MutableLiveData(false)
    val submitSuccess: LiveData<Boolean> = _submitSuccess
    
    private val itemRepository = ItemRepository()
    
    
    /**
     * 上传图片
     */
    fun uploadImage(imageFile: File) {
        _isLoading.value = true
        _errorMessage.value = null
        
        FileUploadManager.uploadFile(imageFile, object : NetworkCallback<String> {
            override fun onSuccess(data: String) {
                // 使用主线程更新LiveData
                Handler(Looper.getMainLooper()).post {
                    _imageUrl.value = data
                    _isLoading.value = false
                    Log.d("ItemMgmtDetailViewModel", "上传成功的图片URL: $data")
                }
            }

            override fun onFailure(errorCode: Int, errorMsg: String) {
                // 使用主线程更新LiveData
                Handler(Looper.getMainLooper()).post {
                    _errorMessage.value = "上传失败: $errorMsg"
                    _isLoading.value = false
                }
            }

            override fun onComplete() {
                // 上传完成后的清理工作
                if (imageFile.exists()) {
                    imageFile.delete()
                }
            }
        })
    }
    
    /**
     * 提交物品信息
     */
    fun submitItem(name: String, content: String, imageUrl: String?) {
        // 验证输入
        if (name.isEmpty()) {
            _errorMessage.value = "请输入物品名称"
            return
        }
        if (content.isEmpty()) {
            _errorMessage.value = "请输入物品描述"
            return
        }
        if (imageUrl == null) {
            _errorMessage.value = "请先拍照"
            return
        }
        
        _isLoading.value = true
        _errorMessage.value = null
        
        // 创建Item对象
        val item = Item(
            name = name,
            content = content,
            file_name = imageUrl
        )
        
        // 使用Repository提交物品
        itemRepository.addItem(item, object : NetworkCallback<Map<String, Any>> {
            override fun onSuccess(data: Map<String, Any>) {
                _isLoading.value = false
                _submitSuccess.value = true
                Log.d("ItemMgmtDetailViewModel", "物品添加成功: $data")
            }

            override fun onFailure(errorCode: Int, errorMsg: String) {
                _isLoading.value = false
                _errorMessage.value = "新增物品失败: $errorMsg"
            }

            override fun onComplete() {
                // 完成回调，不需要特别处理
            }
        })
    }
    
    /**
     * 重置提交成功状态
     */
    fun resetSubmitSuccess() {
        _submitSuccess.value = false
    }
    
    /**
     * 清除错误信息
     */
    fun clearError() {
        _errorMessage.value = null
    }
    
    /**
     * 获取图片URI
     */
    fun getImageUri(): Uri? {
        return _imageUri.value
    }
    
    /**
     * 准备图片数据供UI层使用Coil加载
     * 在MVVM架构中，ViewModel负责准备数据，UI层负责实际的图片加载
     */
    fun prepareImageForCoil(imageUrl: String) {
        Log.d("ItemMgmtDetailViewModel", "准备图片数据: $imageUrl")
        
        // 仅更新图片URL LiveData，UI层将使用Coil直接加载
        Handler(Looper.getMainLooper()).post {
            _imageUrl.value = imageUrl
        }
        
        // 可选：如果UI层需要Uri对象，可以保持以下代码
        try {
            val uri = Uri.parse(imageUrl)
            Handler(Looper.getMainLooper()).post {
                _imageUri.value = uri
            }
        } catch (e: Exception) {
            Log.e("ItemMgmtDetailViewModel", "解析图片URL失败: ${e.message}")
            Handler(Looper.getMainLooper()).post {
                _errorMessage.value = "图片URL格式不正确"
            }
        }
    }
}
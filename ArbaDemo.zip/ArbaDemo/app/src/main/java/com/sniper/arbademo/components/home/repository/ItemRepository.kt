package com.sniper.arbademo.components.home.repository

import com.sniper.arbademo.components.home.model.Item
import com.sniper.arbademo.components.home.model.ItemListData
import com.sniper.arbademo.network.NetworkCallback
import com.sniper.arbademo.network.NetworkClient
import com.sniper.arbademo.network.RetrofitManager
import java.util.concurrent.Executors
import java.util.HashMap
import java.util.Map

/**
 * 物品仓库类，负责处理物品相关的数据操作
 */
class ItemRepository {
    
    /**
     * 获取物品列表
     * @param callback 回调接口
     */
    fun getItemList(callback: NetworkCallback<ItemListData>) {
        // 否则执行真实网络请求
        NetworkClient.request(
            request = { 
                RetrofitManager.getApiService().getItemList() 
            },
            callback = object : NetworkCallback<ItemListData> {
                override fun onSuccess(data: ItemListData) {
                    callback.onSuccess(data)
                }

                override fun onFailure(errorCode: Int, errorMsg: String) {
                    callback.onFailure(errorCode, errorMsg)
                }

                override fun onComplete() {
                    callback.onComplete()
                }
            }
        )
    }
    
    /**
     * 新增物品
     * @param item 物品数据
     * @param callback 回调接口
     */
    fun addItem(item: Item, callback: NetworkCallback<kotlin.collections.Map<String, Any>>) {

        // 否则执行真实网络请求
        NetworkClient.request(
            request = { 
                RetrofitManager.getApiService().addItem(
                    item.name ?: "",
                    content = item.content ?: "",
                    fileName = item.file_name ?: ""
                )
            },
            callback = object : NetworkCallback<kotlin.collections.Map<String, Any>> {
                override fun onSuccess(data: kotlin.collections.Map<String, Any>) {
                    callback.onSuccess(data)
                }

                override fun onFailure(errorCode: Int, errorMsg: String) {
                    callback.onFailure(errorCode, errorMsg)
                }

                override fun onComplete() {
                    callback.onComplete()
                }
            }
        )
    }
}
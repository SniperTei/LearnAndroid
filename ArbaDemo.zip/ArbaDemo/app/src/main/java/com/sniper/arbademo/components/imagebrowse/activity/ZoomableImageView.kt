package com.sniper.arbademo.components.imagebrowse.activity

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Matrix
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import androidx.appcompat.widget.AppCompatImageView
import androidx.core.view.GestureDetectorCompat

/**
 * 支持手势缩放和拖动的ImageView
 */
class ZoomableImageView @JvmOverloads constructor(
    context: Context,
    attrs: android.util.AttributeSet? = null,
    defStyleAttr: Int = 0
) : AppCompatImageView(context, attrs, defStyleAttr) {

    private val matrix = Matrix()
    private val matrixValues = FloatArray(9)
    private val minScale = 1f
    private val maxScale = 5f
    private val midScale = 2.5f
    private var lastX = 0f
    private var lastY = 0f
    private var isScaling = false
    private var isMoving = false
    private var singleTapListener: (() -> Unit)? = null

    private val gestureDetector = GestureDetectorCompat(context, object : GestureDetector.SimpleOnGestureListener() {

        override fun onDoubleTap(e: MotionEvent): Boolean {
            // 双击切换缩放状态
            val currentScale = getCurrentScale()
            
            // 取消任何正在进行的动画
            removeCallbacksAndMessages(null)
            
            if (currentScale < midScale) {
                // 放大到中等缩放，使用动画
                animateScale(midScale)
            } else if (currentScale < maxScale) {
                // 放大到最大缩放，使用动画
                animateScale(maxScale)
            } else {
                // 重置到最小缩放
                animateScale(minScale)
            }
            return true
        }

        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            singleTapListener?.invoke()
            return true
        }

        override fun onLongPress(e: MotionEvent) {
            // 长按事件可以在这里添加
        }
    })

    private val scaleGestureDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {

        override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
            isScaling = true
            // 取消任何正在进行的动画
            removeCallbacksAndMessages(null)
            return true
        }

        override fun onScale(detector: ScaleGestureDetector): Boolean {
            // 使用detector.scaleFactor直接进行连续缩放，提高流畅度
            matrix.postScale(detector.scaleFactor, detector.scaleFactor, detector.focusX, detector.focusY)
            fixTrans() // 使用现有方法处理边界
            imageMatrix = matrix
            return true
        }

        override fun onScaleEnd(detector: ScaleGestureDetector) {
            isScaling = false
            
            val currentScale = getCurrentScale()
            // 如果超出边界，回弹到边界
            if (currentScale < minScale) {
                animateScale(minScale)
            } else if (currentScale > maxScale) {
                animateScale(maxScale)
            }
        }
    })

    init {
        scaleType = ScaleType.MATRIX
        // 启用硬件加速以提高性能
        setLayerType(View.LAYER_TYPE_HARDWARE, null)
    }

    override fun setImageDrawable(drawable: android.graphics.drawable.Drawable?) {
        super.setImageDrawable(drawable)
        // 当设置新的drawable时（如图片加载完成），重置缩放和位置
        if (drawable != null) {
            post { 
                resetScaleAndPosition()
            }
        }
    }

    fun setSingleTapListener(listener: (() -> Unit)?) {
        this.singleTapListener = listener
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        // 处理手势检测
        scaleGestureDetector.onTouchEvent(event)
        gestureDetector.onTouchEvent(event)

        // 处理拖动
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                // 取消任何正在进行的动画
                removeCallbacksAndMessages(null)
                
                lastX = event.x
                lastY = event.y
                isMoving = true
                // 设置视图为可拖动状态
                parent.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_MOVE -> {
                if (!isScaling && isMoving) {
                    val dx = event.x - lastX
                    val dy = event.y - lastY

                    // 允许在任何缩放级别拖动，提高用户体验
                    matrix.postTranslate(dx, dy)
                    fixTrans()
                    imageMatrix = matrix

                    lastX = event.x
                    lastY = event.y
                }
            }
            MotionEvent.ACTION_UP,
            MotionEvent.ACTION_CANCEL -> {
                isMoving = false
                // 恢复父视图的触摸事件拦截
                parent.requestDisallowInterceptTouchEvent(false)
            }
        }

        return true
    }

    // 当视图大小改变时重置矩阵
    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        // 确保在UI线程中执行，避免并发问题
        post { 
            resetScaleAndPosition()
        }
    }

    private fun getCurrentScale(): Float {
        matrix.getValues(matrixValues)
        return matrixValues[Matrix.MSCALE_X]
    }

    // 添加缩放动画，使缩放更平滑
    private fun animateScale(targetScale: Float) {
        val startScale = getCurrentScale()
        val scaleDiff = targetScale - startScale
        val duration = 200L // 动画持续时间
        val startTime = System.currentTimeMillis()
        
        fun updateScale() {
            val elapsed = System.currentTimeMillis() - startTime
            val progress = minOf(elapsed.toFloat() / duration, 1f)
            
            // 使用缓动函数使动画更自然
            val easeOutProgress = 1 - (1 - progress) * (1 - progress)
            val currentScale = startScale + scaleDiff * easeOutProgress
            
            // 计算缩放比例并应用
            val scaleRatio = currentScale / startScale * scaleDiff / (targetScale - startScale)
            matrix.postScale(scaleRatio, scaleRatio, width / 2f, height / 2f)
            
            fixTrans()
            imageMatrix = matrix
            
            if (progress < 1f) {
                // 继续动画
                postDelayed({ updateScale() }, 10)
            }
        }
        
        // 开始动画
        updateScale()
    }
    
    // 添加方法用于取消所有回调和动画
    private fun removeCallbacksAndMessages(token: Any?) {
        if (handler != null) {
            handler.removeCallbacksAndMessages(token)
        }
    }

    fun resetScaleAndPosition() {
        // 取消任何正在进行的动画
        removeCallbacksAndMessages(null)
        
        matrix.reset()
        // 如果有drawable，计算合适的初始缩放和位置
        drawable?.let {
            val scale = calculateInitialScale(it.intrinsicWidth, it.intrinsicHeight, width, height)
            val translateX = (width - it.intrinsicWidth * scale) / 2f
            val translateY = (height - it.intrinsicHeight * scale) / 2f
            matrix.setScale(scale, scale)
            matrix.postTranslate(translateX, translateY)
        }
        fixTrans() // 确保正确处理边界
        imageMatrix = matrix
    }

    private fun calculateInitialScale(imageWidth: Int, imageHeight: Int, viewWidth: Int, viewHeight: Int): Float {
        if (imageWidth == 0 || imageHeight == 0 || viewWidth == 0 || viewHeight == 0) return 1f
        
        val scaleX = viewWidth.toFloat() / imageWidth
        val scaleY = viewHeight.toFloat() / imageHeight
        return minOf(scaleX, scaleY)
    }

    private fun fixTrans() {
        val values = FloatArray(9)
        matrix.getValues(values)
        var transX = values[Matrix.MTRANS_X]
        var transY = values[Matrix.MTRANS_Y]

        val scale = getCurrentScale()
        val viewWidth = width.toFloat()
        val viewHeight = height.toFloat()

        // 计算图片实际显示的宽高
        val imageWidth = drawable?.intrinsicWidth?.times(scale) ?: viewWidth
        val imageHeight = drawable?.intrinsicHeight?.times(scale) ?: viewHeight

        // 限制水平拖动范围
        val minTransX = (viewWidth - imageWidth) / 2f
        val maxTransX = (viewWidth - imageWidth) / 2f
        
        // 限制垂直拖动范围
        val minTransY = (viewHeight - imageHeight) / 2f
        val maxTransY = (viewHeight - imageHeight) / 2f

        // 应用边界限制
        transX = transX.coerceIn(minTransX, maxTransX)
        transY = transY.coerceIn(minTransY, maxTransY)

        if (values[Matrix.MTRANS_X] != transX || values[Matrix.MTRANS_Y] != transY) {
            matrix.postTranslate(transX - values[Matrix.MTRANS_X], transY - values[Matrix.MTRANS_Y])
        }
    }
}
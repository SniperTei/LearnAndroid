package com.sniper.arbademo.components.home.repository

import android.os.Handler
import android.os.Looper
import com.sniper.arbademo.components.home.model.CheckInRecordListData
import com.sniper.arbademo.components.home.model.Item
import com.sniper.arbademo.components.home.model.ItemListData
import com.sniper.arbademo.network.NetworkCallback
import com.sniper.arbademo.network.NetworkClient
import com.sniper.arbademo.network.RetrofitManager
import java.util.concurrent.Executors

/**
 * 打卡页面的数据仓库，负责获取物品列表数据
 */
class CheckInRepository {

    private val executorService = Executors.newSingleThreadExecutor()
    
    /**
     * 获取物品列表
     * @param callback 回调接口
     */
    fun getItemList(callback: NetworkCallback<ItemListData>) {
        
        // 否则执行真实网络请求
        NetworkClient.request(
            request = { 
                RetrofitManager.getApiService().getItemList() 
            },
            callback = object : NetworkCallback<ItemListData> {
                override fun onSuccess(data: ItemListData) {
                    callback.onSuccess(data)
                }

                override fun onFailure(errorCode: Int, errorMsg: String) {
                    callback.onFailure(errorCode, errorMsg)
                }

                override fun onComplete() {
                    callback.onComplete()
                }
            }
        )
    }
    
    
    /**
     * 执行打卡操作
     * @param itemsId 物品ID
     * @param fileName 打卡照片文件名
     * @param callback 回调接口
     */
    fun performCheckIn(itemsId: String, fileName: String, callback: NetworkCallback<Any>) {
        
        // 执行真实网络请求
        NetworkClient.request(
            request = { 
                RetrofitManager.getApiService().addCheckIn(itemsId, fileName)
            },
            callback = object : NetworkCallback<Map<String, Any>> {
                override fun onSuccess(data: Map<String, Any>) {
                    callback.onSuccess(data)
                }

                override fun onFailure(errorCode: Int, errorMsg: String) {
                    callback.onFailure(errorCode, errorMsg)
                }

                override fun onComplete() {
                    callback.onComplete()
                }
            }
        )
    }

    /**
     * 获取打卡记录列表
     */
    fun getCheckInRecordList(callback: NetworkCallback<CheckInRecordListData>) {
        
        // 否则执行真实网络请求
        NetworkClient.request(
            request = { 
                RetrofitManager.getApiService().getCheckInList() 
            },
            callback = object : NetworkCallback<CheckInRecordListData> {
                override fun onSuccess(data: CheckInRecordListData) {
                    callback.onSuccess(data)
                }

                override fun onFailure(errorCode: Int, errorMsg: String) {
                    callback.onFailure(errorCode, errorMsg)
                }

                override fun onComplete() {
                    callback.onComplete()
                }
            }
        )
    }

    /**
     * 评分打卡记录
     */
    fun scoreCheckIn(recordId: String, score: Int, callback: NetworkCallback<Map<String, Any>>) {
        
        // 执行真实网络请求
        NetworkClient.request(
            request = { 
                RetrofitManager.getApiService().scoreCheckIn(recordId, score)
            },
            callback = object : NetworkCallback<Map<String, Any>> {
                override fun onSuccess(data: Map<String, Any>) {
                    callback.onSuccess(data)
                }

                override fun onFailure(errorCode: Int, errorMsg: String) {
                    callback.onFailure(errorCode, errorMsg)
                }

                override fun onComplete() {
                    callback.onComplete()
                }
            }
        )
    }
}
package com.sniper.arbademo.components.home.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil3.load
import com.sniper.arbademo.R
import com.sniper.arbademo.base.fragment.BaseFragment
import com.sniper.arbademo.components.home.model.Item
import com.sniper.arbademo.components.home.viewmodel.CheckInViewModel
import com.sniper.arbademo.databinding.FragmentCheckInBinding
import com.sniper.arbademo.network.NetworkConfig

/**
 * 打卡页面Fragment
 * 采用完整MVVM架构模式，使用CheckInViewModel和CheckInRepository获取数据
 */
class CheckInFragment : BaseFragment() {
    private lateinit var viewModel: CheckInViewModel
    private var _binding: FragmentCheckInBinding? = null
    private val binding get() = _binding!!
    
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentCheckInBinding.inflate(inflater, container, false)
        
        // 初始化ViewModel
        viewModel = ViewModelProvider(this)[CheckInViewModel::class.java]
        
        // 设置RecyclerView
        binding.recyclerViewItems.layoutManager = LinearLayoutManager(requireContext())
        
        // 加载物品列表
        loadItems()
        
        // 设置新增按钮点击事件
//        binding.fabAddCheckIn.setOnClickListener {
//            navigateToDetail(null)
//        }
        
        return binding.root
    }
    
    /**
     * 跳转到详情页
     * @param item 要编辑的项目，为null表示新增
     */
    private fun navigateToDetail(item: Item?) {
//        val detailFragment = CheckInDetailFragment.newInstance(
//            item?.id ?: "",
//            item?.name ?: "",
//            item?.content ?: ""
//        )
//
//        // 使用FragmentManager进行页面切换
//        parentFragmentManager.beginTransaction()
//            .replace(R.id.container, detailFragment)
//            .addToBackStack(null)
//            .commit()
    }
    
    /**
     * 刷新列表数据
     */
    fun refreshList() {
        loadItems()
    }
    
    /**
     * 加载物品列表数据
     */
    private fun loadItems() {
        viewModel.loadItems(object : CheckInViewModel.ItemsStateListener {
            override fun onLoading() {
                // 确保在主线程上更新UI
                requireActivity().runOnUiThread {
                    showLoading()
                }
            }

            override fun onSuccess(items: com.sniper.arbademo.components.home.model.ItemListData?) {
                // 确保在主线程上更新UI
                requireActivity().runOnUiThread {
                    showItems(items)
                }
            }

            override fun onError(message: String) {
                // 确保在主线程上更新UI
                requireActivity().runOnUiThread {
                    showError(message)
                }
            }
        })
    }
    
    private fun showLoading() {
        binding.progressBar.visibility = View.VISIBLE
        binding.recyclerViewItems.visibility = View.GONE
        binding.emptyView.visibility = View.GONE
    }
    
    private fun showItems(items: com.sniper.arbademo.components.home.model.ItemListData?) {
        binding.progressBar.visibility = View.GONE
        
        if (items?.total == 0 || items?.rows.isNullOrEmpty()) {
            binding.recyclerViewItems.visibility = View.GONE
            binding.emptyView.visibility = View.VISIBLE
        } else {
            binding.recyclerViewItems.visibility = View.VISIBLE
            binding.emptyView.visibility = View.GONE
            // 设置适配器
            binding.recyclerViewItems.adapter = ItemAdapter(items?.rows ?: emptyList())
        }
    }
    
    /**
     * 显示错误信息
     */
    private fun showError(message: String) {
        binding.progressBar.visibility = View.GONE
        binding.recyclerViewItems.visibility = View.GONE
        binding.emptyView.visibility = View.VISIBLE
        binding.emptyView.text = message
    }
    
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
    
    /**
     * 物品列表适配器
     */
    private inner class ItemAdapter(private val items: List<Item>) : 
        RecyclerView.Adapter<ItemAdapter.ItemViewHolder>() {
        
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_item_management, parent, false)
            return ItemViewHolder(view)
        }
        
        override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
            val item = items[position]
            holder.bind(item)
        }
        
        override fun getItemCount(): Int = items.size
        
        inner class ItemViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            private val tvItemName: TextView = itemView.findViewById(R.id.tv_item_name)
            private val tvItemContent: TextView = itemView.findViewById(R.id.tv_item_content)
            private val ivItemImage: ImageView = itemView.findViewById(R.id.iv_item_image)
            
            fun bind(item: Item) {
                tvItemName.text = item.name
                tvItemContent.text = item.content
                
                // 加载图片（如果有图片URL）
                if (item.itemimage?.isNotEmpty() == true) {
                    val imageUrl = "${NetworkConfig.BASE_URL}${item.itemimage}"
                    ivItemImage.load(imageUrl)
                } else {
                    // 设置默认图片
                    ivItemImage.setImageResource(R.drawable.ic_launcher_background)
                }
                
                // 设置整个item的点击事件（查看详情）
                itemView.setOnClickListener {
                    navigateToDetail(item)
                }
                
                // 设置打卡按钮的点击事件
                val btnCheckIn: Button = itemView.findViewById(R.id.btn_check_in)
                btnCheckIn.setOnClickListener {
                    // 跳转到打卡详情页
                    val checkInDetailFragment = CheckInDetailFragment.newInstanceForCheckIn(item)
                    parentFragmentManager.beginTransaction()
                        .replace(id, checkInDetailFragment)
                        .addToBackStack(null)
                        .commit()
                }
            }
        }
    }
}
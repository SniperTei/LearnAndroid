package com.sniper.arbademo.network

/**
 * 通用网络响应数据类
 * @param T 响应数据类型
 */
data class BaseResponse<T>(
    val code: Int = 0,
    val msg: String = "",
    val data: T? = null
) {
    /**
     * 判断响应是否成功
     * 根据服务器定义，code为1时表示成功
     */
    fun isSuccess(): Boolean = code == 1
}
package com.sniper.arbademo.components.camera.repository

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import androidx.activity.result.ActivityResult
import androidx.core.content.FileProvider
import com.sniper.arbademo.components.camera.model.CameraParams
import com.sniper.arbademo.components.camera.model.CameraResult
import com.sniper.arbademo.manager.UserManager
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

/**
 * 相机仓库类，负责处理相机相关的操作
 */
class CameraRepository(private val context: Context) {
    
    /**
     * 创建相机意图，用于启动相机Activity
     */
    fun createCameraIntent(params: CameraParams): Pair<Intent, File> {
        val photoFile = createImageFile(params)
        val photoUri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            photoFile
        )
        
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        intent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri)
        intent.putExtra(MediaStore.EXTRA_SCREEN_ORIENTATION, 0) // 锁定为竖屏

        // TODO 先不设置闪光灯
        // 根据参数设置闪光灯模式
//        when (params.flashMode) {
//            com.sniper.arbademo.components.camera.model.FlashMode.ON ->
//                intent.putExtra(MediaStore.EXTRA_FLASH_MODE, Camera.MEDIA_ACTION_ALL)
//            com.sniper.arbademo.components.camera.model.FlashMode.OFF ->
//                intent.putExtra(MediaStore.EXTRA_FLASH_MODE, Camera.MEDIA_ACTION_NONE)
//            com.sniper.arbademo.components.camera.model.FlashMode.AUTO ->
//                intent.putExtra(MediaStore.EXTRA_FLASH_MODE, Camera.MEDIA_ACTION_AUTO)
//        }
        
        return Pair(intent, photoFile)
    }
    
    /**
     * 处理相机Activity返回的结果
     */
    suspend fun processCameraResult(
        result: ActivityResult,
        photoFile: File,
        params: CameraParams
    ): CameraResult? = suspendCoroutine { continuation ->
        if (result.resultCode == android.app.Activity.RESULT_OK && photoFile.exists()) {
            // 处理水印
            val finalPhotoFile = if (params.enableWatermark) {
                addWatermarkToImage(photoFile, params)
            } else {
                photoFile
            }
            
            // 如果需要保存到相册
            if (params.saveToGallery) {
                saveImageToGallery(finalPhotoFile)
            }
            
            // 获取图片信息
            val imageUri = Uri.fromFile(finalPhotoFile)
            val imageWidth = 0 // 这里可以添加获取图片实际宽度的代码
            val imageHeight = 0 // 这里可以添加获取图片实际高度的代码
            val timestamp = System.currentTimeMillis()
            
            val cameraResult = CameraResult(
                imageUri = imageUri,
                imagePath = finalPhotoFile.absolutePath,
                imageWidth = imageWidth,
                imageHeight = imageHeight,
                timestamp = timestamp
            )
            
            continuation.resume(cameraResult)
        } else {
            continuation.resume(null)
        }
    }
    
    /**
     * 为图片添加水印
     * @param photoFile 原始图片文件
     * @param params 相机参数，包含水印相关配置
     * @return 添加水印后的图片文件
     */
    private fun addWatermarkToImage(photoFile: File, params: CameraParams): File {
        try {
            // 获取水印文本
            val watermarkText = params.watermarkText ?: generateDefaultWatermark()
            
            // 读取图片
            val bitmap = MediaStore.Images.Media.getBitmap(context.contentResolver, Uri.fromFile(photoFile))
            val mutableBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true)
            bitmap.recycle()
            
            // 创建画布
            val canvas = Canvas(mutableBitmap)
            
            // 设置水印样式
            val paint = Paint().apply {
                color = Color.WHITE
                textSize = 40f
                isAntiAlias = true
                alpha = 180 // 设置透明度，0-255
            }
            
            // 计算水印位置（右下角）
            val margin = 50f
            val textWidth = paint.measureText(watermarkText)
            val textHeight = -paint.ascent()
            val x = canvas.width - textWidth - margin
            val y = canvas.height - margin
            
            // 添加水印
            canvas.drawText(watermarkText, x, y, paint)
            
            // 根据输出格式确定压缩格式
            val compressFormat = when (params.outputFormat) {
                com.sniper.arbademo.components.camera.model.OutputFormat.PNG -> Bitmap.CompressFormat.PNG
                com.sniper.arbademo.components.camera.model.OutputFormat.WEBP -> Bitmap.CompressFormat.WEBP
                else -> Bitmap.CompressFormat.JPEG
            }
            
            // 确定质量参数（PNG是无损压缩，不需要质量参数）
            val quality = if (compressFormat == Bitmap.CompressFormat.PNG) 100 else 95
            
            // 获取正确的文件扩展名
            val extension = when (params.outputFormat) {
                com.sniper.arbademo.components.camera.model.OutputFormat.PNG -> ".png"
                com.sniper.arbademo.components.camera.model.OutputFormat.WEBP -> ".webp"
                else -> ".jpg"
            }
            
            // 保存图片
            val outputFile = File(photoFile.parent, "${photoFile.nameWithoutExtension}_watermark$extension")
            FileOutputStream(outputFile).use { out ->
                mutableBitmap.compress(compressFormat, quality, out)
            }
            mutableBitmap.recycle()
            
            return outputFile
        } catch (e: Exception) {
            e.printStackTrace()
            // 如果添加水印失败，返回原图
            return photoFile
        }
    }
    
    /**
     * 创建图片文件
     */
    private fun createImageFile(params: CameraParams): File {
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val imageFileName = "JPEG_${timeStamp}_"
        val storageDir = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        
        val extension = when (params.outputFormat) {
            com.sniper.arbademo.components.camera.model.OutputFormat.JPEG -> ".jpg"
            com.sniper.arbademo.components.camera.model.OutputFormat.PNG -> ".png"
            com.sniper.arbademo.components.camera.model.OutputFormat.WEBP -> ".webp"
        }
        
        return File.createTempFile(
            imageFileName,
            extension,
            storageDir
        )
    }
    
    /**
     * 保存图片到相册
     */
    private fun saveImageToGallery(photoFile: File) {
        try {
            MediaStore.Images.Media.insertImage(
                context.contentResolver,
                photoFile.absolutePath,
                photoFile.name,
                "拍摄的照片"
            )
            
            // 发送广播通知系统更新媒体库
            context.sendBroadcast(
                Intent(
                    Intent.ACTION_MEDIA_SCANNER_SCAN_FILE,
                    Uri.fromFile(photoFile)
                )
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    
    /**
     * 生成默认水印：日期+时间+用户ID
     */
    private fun generateDefaultWatermark(): String {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        val dateTime = dateFormat.format(Date())
        
        // 获取用户昵称，如果没有则显示"Unknown"
        val nickname = try {
            // val id = UserManager.getUserId(context)
            // if (id > 0) id.toString() else "Unknown"
            val nickname = UserManager.getNickname() ?: "Unknown"
            nickname.ifEmpty { "Unknown" }
        } catch (e: Exception) {
            "Unknown"
        }
        
        return "$dateTime | User: $nickname"
    }
}
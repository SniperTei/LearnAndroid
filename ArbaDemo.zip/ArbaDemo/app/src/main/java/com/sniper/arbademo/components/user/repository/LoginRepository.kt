package com.sniper.arbademo.components.user.repository

import com.sniper.arbademo.components.user.model.UserResponse
import com.sniper.arbademo.network.NetworkCallback
import com.sniper.arbademo.network.NetworkClient
import com.sniper.arbademo.network.RetrofitManager

/**
 * 登录仓库
 * 负责处理登录相关的数据请求和数据转换
 */
class LoginRepository {
    /**
     * 用户登录
     * @param account 账号
     * @param password 密码
     * @param callback 回调接口
     */
    fun login(account: String, password: String, callback: NetworkCallback<UserResponse>) {
        // 执行网络请求
        NetworkClient.request(
            request = { 
                // 调用API服务进行登录
                RetrofitManager.getApiService().login(account, password) 
            },
            callback = object : NetworkCallback<Map<String, Any>> {
                override fun onSuccess(data: Map<String, Any>) {
                    try {
                        // 解析嵌套的userinfo数据
                        val userInfo = data["userinfo"] as? Map<String, Any> ?: emptyMap()
                        
                        // 将Map转换为UserResponse对象
                        val userResponse = parseUserResponse(userInfo)
                        callback.onSuccess(userResponse)
                    } catch (e: Exception) {
                        // 数据解析失败
                        callback.onFailure(1001, "数据解析失败")
                    }
                }
                
                override fun onFailure(errorCode: Int, errorMsg: String) {
                    // 转发失败信息
                    callback.onFailure(errorCode, errorMsg)
                }
                
                override fun onComplete() {
                    // 转发完成事件
                    callback.onComplete()
                }
            }
        )
    }
    
    /**
     * 解析用户响应数据
     * @param userInfo 用户信息Map
     * @return UserResponse 对象
     */
    private fun parseUserResponse(userInfo: Map<String, Any>): UserResponse {
        return UserResponse(
            id = (userInfo["id"] as? Number)?.toInt() ?: 0,
            username = userInfo["username"]?.toString() ?: "",
            nickname = userInfo["nickname"]?.toString() ?: "",
            mobile = userInfo["mobile"]?.toString() ?: "",
            avatar = userInfo["avatar"]?.toString() ?: "",
            score = (userInfo["score"] as? Number)?.toInt() ?: 0,
            token = userInfo["token"]?.toString() ?: "",
            user_id = (userInfo["user_id"] as? Number)?.toInt() ?: 0,
            createtime = (userInfo["createtime"] as? Number)?.toLong() ?: 0,
            expiretime = (userInfo["expiretime"] as? Number)?.toLong() ?: 0,
            expires_in = (userInfo["expires_in"] as? Number)?.toInt() ?: 0
        )
    }
}
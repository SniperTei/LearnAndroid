package com.sniper.arbademo.components.user.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sniper.arbademo.components.user.model.UserResponse
import com.sniper.arbademo.components.user.repository.LoginRepository
import com.sniper.arbademo.network.NetworkCallback
import com.sniper.arbademo.manager.UserManager
import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * 登录ViewModel
 */
class LoginViewModel : ViewModel() {
    private val repository = LoginRepository()
    
    // 登录UI状态 - 使用StateFlow替代LiveData
    private val _uiState = MutableStateFlow<LoginUiState>(LoginUiState.Idle)
    val uiState: StateFlow<LoginUiState> = _uiState.asStateFlow()
    
    // 登录输入数据 - 使用StateFlow替代LiveData
    private val _loginInput = MutableStateFlow(LoginInput())
    val loginInput: StateFlow<LoginInput> = _loginInput.asStateFlow()
    
    /**
     * 更新登录输入数据
     */
    fun updateLoginInput(account: String = _loginInput.value.account, 
                       password: String = _loginInput.value.password) {
        viewModelScope.launch { // 在协程中更新状态
            _loginInput.update { currentInput ->
                currentInput.copy(
                    account = account,
                    password = password
                )
            }
        }
    }
    
    /**
     * 重置UI状态到初始状态
     */
    fun resetUiState() {
        viewModelScope.launch {
            _uiState.value = LoginUiState.Idle
        }
    }
    
    /**
     * 登录结果数据类
     */
    data class LoginResult(val userResponse: UserResponse)
    
    /**
     * 登录页面的输入数据
     */
    data class LoginInput(
        val account: String = "",
        val password: String = ""
    )
    
    /**
     * 登录状态密封类（UI 层观察的状态）
     */
    sealed class LoginUiState {
        object Idle : LoginUiState()          // 初始状态
        object Loading : LoginUiState()       // 加载中
        data class Success(val result: LoginResult) : LoginUiState() // 成功
        data class Error(val message: String) : LoginUiState() // 失败
    }
    
    /**
     * 登录
     * @param context 上下文
     * @param account 账号
     * @param password 密码
     */
    fun login(context: Context, account: String, password: String) {
        viewModelScope.launch {
            // 更新输入数据
            updateLoginInput(account, password)
            
            // 参数校验
            if (account.isEmpty()) {
                _uiState.value = LoginUiState.Error("请输入账号")
                return@launch
            }
            
            if (password.isEmpty()) {
                _uiState.value = LoginUiState.Error("请输入密码")
                return@launch
            }
            
            // 设置加载状态
            _uiState.value = LoginUiState.Loading
        }
        
        // 执行登录
        repository.login(account, password, object : NetworkCallback<UserResponse> {
            override fun onSuccess(data: UserResponse) {
                viewModelScope.launch {
                    // 保存用户信息
                    UserManager.saveUserLogin(context, data)
                    
                    // 设置登录成功状态
                    _uiState.value = LoginUiState.Success(LoginResult(data))
                }
            }
            
            override fun onFailure(errorCode: Int, errorMsg: String) {
                viewModelScope.launch {
                    _uiState.value = LoginUiState.Error(errorMsg)
                }
            }
            
            override fun onComplete() {
                // 请求完成，可以在这里做一些清理工作
            }
        })
    }
}
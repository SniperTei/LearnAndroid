package com.sniper.arbademo.base.activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.content.Intent

/**
 * Activity基类，提供通用功能和生命周期管理
 */
open class BaseActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 可以在这里添加所有Activity通用的初始化代码
        // 例如：设置状态栏、初始化日志、通用的错误处理等
    }

    /**
     * 通用的页面跳转方法
     */
    protected fun startActivity(clazz: Class<*>) {
        startActivity(Intent(this, clazz))
    }

    /**
     * 带返回值的页面跳转方法
     */
    protected fun startActivityForResult(clazz: Class<*>, requestCode: Int) {
        startActivityForResult(Intent(this, clazz), requestCode)
    }

    /**
     * 显示Toast消息的通用方法（可在子类中重写以使用自定义Toast）
     */
    protected open fun showToast(message: String) {
        android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        // 可以在这里添加资源释放、监听器解绑等通用清理代码
    }
}
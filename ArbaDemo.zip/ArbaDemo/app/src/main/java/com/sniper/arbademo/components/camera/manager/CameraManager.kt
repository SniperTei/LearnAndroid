package com.sniper.arbademo.components.camera.manager

import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultCallback
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.MainThread
import androidx.fragment.app.Fragment
import androidx.lifecycle.*
import com.sniper.arbademo.components.camera.model.CameraParams
import com.sniper.arbademo.components.camera.model.CameraResult
import com.sniper.arbademo.components.camera.model.CameraState
import com.sniper.arbademo.components.camera.viewmodel.CameraViewModel
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.io.File

/**
 * 相机管理器，简化相机功能的调用
 * 使用单例模式，提供静态方法接口
 */
class CameraManager private constructor() {
    
    companion object {
        private const val TAG = "CameraManager"
        // 单例实例
        @Volatile
        private var INSTANCE: CameraManager? = null
        
        /**
         * 获取CameraManager实例
         */
        fun getInstance(): CameraManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: CameraManager().also { INSTANCE = it }
            }
        }
        
        /**
         * 拍照（静态方法，使用DSL风格简化调用）
         */
        @MainThread
        fun takePhoto(
            owner: LifecycleOwner,
            params: CameraParams = CameraParams(),
            block: CameraCallbackBuilder.() -> Unit
        ) {
            getInstance().takePhoto(owner, params, block)
        }
        
        /**
         * 清理资源（静态方法）
         */
        fun cleanup(owner: LifecycleOwner) {
            getInstance().cleanupInternal(owner)
        }
    }
    
    // 移除旧的回调接口，使用DSL风格的回调构建器
    
    // 存储不同生命周期所有者对应的ViewModel和结果启动器
    private val viewModelMap = mutableMapOf<LifecycleOwner, CameraViewModel>()
    private val launcherMap = mutableMapOf<LifecycleOwner, ActivityResultLauncher<Intent>>()
    
    /**
     * 初始化相机管理器
     * 必须在Activity或Fragment的onCreate或onCreateView中调用
     */
    @MainThread
    fun initialize(activity: ComponentActivity) {
        if (!launcherMap.containsKey(activity)) {
            // 获取或创建ViewModel
            val viewModel = ViewModelProvider(activity)[CameraViewModel::class.java]
            viewModelMap[activity] = viewModel
            
            // 注册Activity结果启动器
            val launcher = activity.registerForActivityResult(
                ActivityResultContracts.StartActivityForResult(),
                createResultCallback(activity)
            )
            launcherMap[activity] = launcher
            
            // 监听生命周期，清理资源
            activity.lifecycle.addObserver(object : DefaultLifecycleObserver {
                override fun onDestroy(owner: LifecycleOwner) {
                    cleanup(owner)
                }
            })
        }
    }
    
    /**
     * 初始化相机管理器（Fragment版本）
     */
    @MainThread
    fun initialize(fragment: Fragment) {
        if (!launcherMap.containsKey(fragment)) {
            // 获取或创建ViewModel
            val viewModel = ViewModelProvider(fragment)[CameraViewModel::class.java]
            viewModelMap[fragment] = viewModel
            
            // 注册Activity结果启动器
            val launcher = fragment.registerForActivityResult(
                ActivityResultContracts.StartActivityForResult(),
                createResultCallback(fragment)
            )
            launcherMap[fragment] = launcher
            
            // 监听生命周期，清理资源
            fragment.lifecycle.addObserver(object : DefaultLifecycleObserver {
                override fun onDestroy(owner: LifecycleOwner) {
                    cleanup(owner)
                }
            })
        }
    }
    
    /**
     * 拍照（使用DSL风格回调）
     * @param owner Activity或Fragment的生命周期所有者
     * @param params 相机参数
     * @param block DSL风格的回调配置
     */
    @MainThread
    fun takePhoto(
        owner: LifecycleOwner,
        params: CameraParams = CameraParams(),
        block: CameraCallbackBuilder.() -> Unit
    ) {
        // 确保初始化
        initializeIfNeeded(owner)
        
        val builder = CameraCallbackBuilder().apply(block)
        takePhotoInternal(owner, params, builder)
    }
    
    /**
     * 拍照回调构建器，使用DSL风格
     */
    class CameraCallbackBuilder {
        var onImageCaptured: (java.io.File) -> Unit = {}
        var onCameraCanceled: () -> Unit = {}
        var onError: () -> Unit = {}
    }
    
    // 相机回调内部类，用于处理DSL回调
    private inner class CameraCallbackImpl(
        private val onImageCaptured: (java.io.File) -> Unit,
        private val onCameraCanceled: () -> Unit,
        private val onError: () -> Unit
    ) {
        fun onImageCaptured(imageFile: java.io.File) {
            Log.i(TAG, "onImageCaptured: ${imageFile.absolutePath}")
            onImageCaptured.invoke(imageFile)
        }
        
        fun onCameraCanceled() {
//            Log.i(TAG, "onCameraCanceled")
//            onCameraCanceled.invoke()
        }
        
        fun onError() {
            Log.i(TAG, "onError")
            onError.invoke()
        }
    }
    
    /**
     * 拍照（内部实现）
     */
    @MainThread
    private fun takePhotoInternal(
        owner: LifecycleOwner,
        params: CameraParams = CameraParams(),
        callbackBuilder: CameraCallbackBuilder
    ) {
        val viewModel = getViewModel(owner)
        val launcher = getLauncher(owner)
        
        // 创建回调实现
        val callback = CameraCallbackImpl(
            onImageCaptured = callbackBuilder.onImageCaptured,
            onCameraCanceled = callbackBuilder.onCameraCanceled,
            onError = callbackBuilder.onError
        )

        // 观察相机状态
        owner.lifecycleScope.launch {
            viewModel.cameraState.collect { state: CameraState ->
                when (state) {
                    is CameraState.Success -> {
                        state.result?.let { result -> callback.onImageCaptured(File(result.imagePath)) }
                        viewModel.clearError()
                    }
                    is CameraState.Error -> {
                        callback.onError()
                        viewModel.clearError()
                    }
                    is CameraState.Cancelled -> {
                        callback.onCameraCanceled()
                    }
                    else -> {}
                }
            }
        }
        
        // 启动相机
        val intent = viewModel.prepareCamera(params)
        launcher.launch(intent)
    }
    
    /**
     * 初始化（如果需要）
     */
    private fun initializeIfNeeded(owner: LifecycleOwner) {
        if (!launcherMap.containsKey(owner)) {
            when (owner) {
                is ComponentActivity -> initialize(owner)
                is Fragment -> initialize(owner)
                else -> throw IllegalArgumentException("Owner must be Activity or Fragment")
            }
        }
    }
    
    /**
     * 创建相机结果回调
     */
    private fun createResultCallback(owner: LifecycleOwner): ActivityResultCallback<ActivityResult> {
        return ActivityResultCallback { result ->
            val viewModel = getViewModel(owner)
            viewModel.handleCameraResult(result)
        }
    }
    
    /**
     * 获取ViewModel
     */
    private fun getViewModel(owner: LifecycleOwner): CameraViewModel {
        return viewModelMap[owner] ?: throw IllegalStateException("CameraManager not initialized for this lifecycle owner")
    }
    
    /**
     * 获取结果启动器
     */
    private fun getLauncher(owner: LifecycleOwner): ActivityResultLauncher<Intent> {
        return launcherMap[owner] ?: throw IllegalStateException("CameraManager not initialized for this lifecycle owner")
    }
    
    /**
     * 清理资源（内部实现）
     */
    private fun cleanupInternal(owner: LifecycleOwner) {
        viewModelMap.remove(owner)
        launcherMap.remove(owner)
    }
}
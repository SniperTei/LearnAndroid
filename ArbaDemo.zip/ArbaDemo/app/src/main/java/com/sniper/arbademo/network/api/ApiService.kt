package com.sniper.arbademo.network.api

import com.sniper.arbademo.components.home.model.CheckInRecordListData
import com.sniper.arbademo.components.home.model.ItemListData
import com.sniper.arbademo.network.BaseResponse
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.Multipart
import retrofit2.http.POST

/**
 * API接口定义
 */
interface ApiService {
    /**
     * 用户登录
     * @param account 账号
     * @param password 密码
     */
    @FormUrlEncoded
    @POST("/api/user/login")
    suspend fun login(
        @Field("account") account: String,
        @Field("password") password: String
    ): BaseResponse<Map<String, Any>>

    /**
     * 用户注册
     * @param account 账号
     * @param password 密码
     */
    @FormUrlEncoded
    @POST("/api/user/register")
    suspend fun register(
        @Field("username") username: String,
        @Field("password") password: String,
        @Field("confirmPassword") confirmPassword: String
    ): BaseResponse<Map<String, Any>>

    // 公共接口

    /**
     * 上传文件
     * @param file 要上传的文件
     */
    @Multipart
    @POST("/api/common/upload")
    suspend fun uploadFile(
        @retrofit2.http.Part file: okhttp3.MultipartBody.Part
    ): BaseResponse<Map<String, Any>>

    // 物品相关接口
    
    /**
     * 获取物品列表（管理员才有权限）
     */
    @POST("/api/items/list")
    suspend fun getItemList(): BaseResponse<ItemListData>

    /**
     * 新增物品（管理员才有权限）
     */
    @FormUrlEncoded
    @POST("/api/items/additem")
    suspend fun addItem(
        @Field("name") name: String,
        @Field("content") content: String,
        @Field("file_name") fileName: String
    ): BaseResponse<Map<String, Any>>

    /**
     * 物品详情
     * @param itemId 物品ID
     */
    @POST("/api/items/itemsone")
    suspend fun getItemDetail(
        @Field("id") itemId: Int
    ): BaseResponse<Map<String, Any>>

    // 打卡相关接口

    /**
     * 打卡
     * @param content 打卡内容
     * @param itemimage 打卡物品图片路径
     */
    @FormUrlEncoded
    @POST("/api/itemrecord/addclock")
    suspend fun addCheckIn(
        @Field("items_id") itemsId: String,
        @Field("file_name") fileName: String
    ): BaseResponse<Map<String, Any>>

    /**
     * 打卡记录列表
     * @param status 状态（可选）
     * @param userId 用户ID（可选）
     */
    @FormUrlEncoded
    @POST("/api/itemrecord/clocklist")
    suspend fun getCheckInList(
        @Field("status") status: String? = null,
        @Field("username") userId: String? = null
    ): BaseResponse<CheckInRecordListData>

    /**
     * 打分
     */
    @FormUrlEncoded
    @POST("/api/itemrecord/clockitem")
    suspend fun scoreCheckIn(
        @Field("id") id: String, // 物品记录ID
        @Field("score") score: Int
    ): BaseResponse<Map<String, Any>>
}
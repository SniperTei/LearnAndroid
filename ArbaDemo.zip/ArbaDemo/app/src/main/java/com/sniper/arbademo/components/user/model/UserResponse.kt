package com.sniper.arbademo.components.user.model

/**
 * 用户信息响应模型
 */
data class UserResponse(
    val id: Int = 0,
    val username: String = "",
    val nickname: String = "",
    val mobile: String = "",
    val avatar: String = "",
    val score: Int = 0,
    val token: String = "",
    val user_id: Int = 0,
    val createtime: Long = 0,
    val expiretime: Long = 0,
    val expires_in: Int = 0
)
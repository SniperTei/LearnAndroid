package com.sniper.arbademo.network

import android.content.Context
import android.os.Build
import com.sniper.arbademo.manager.UserManager
import com.sniper.arbademo.network.api.ApiService
import okhttp3.Cache
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Retrofit实例管理类
 */
object RetrofitManager {
    private lateinit var retrofit: Retrofit
    private lateinit var apiService: ApiService
    
    /**
     * 初始化Retrofit
     */
    fun init(context: Context) {
        // 创建OkHttp客户端
        val okHttpClient = buildOkHttpClient(context)
        
        // 创建Retrofit实例
        retrofit = Retrofit.Builder()
            .baseUrl(NetworkConfig.BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        
        // 创建API服务实例
        apiService = retrofit.create(ApiService::class.java)
    }
    
    /**
     * 构建OkHttpClient
     */
    private fun buildOkHttpClient(context: Context): OkHttpClient {
        // 日志拦截器
        val loggingInterceptor = HttpLoggingInterceptor().apply {
            level = if (NetworkConfig.SHOW_LOG) {
                HttpLoggingInterceptor.Level.BODY
            } else {
                HttpLoggingInterceptor.Level.NONE
            }
        }
        
        // 缓存目录
        val cacheDir = File(context.cacheDir, "http_cache")
        val cache = Cache(cacheDir, 10 * 1024 * 1024) // 10MB缓存
        
        // 创建token拦截器
        val tokenInterceptor = Interceptor { chain ->
            val token = UserManager.getToken()
            val request = chain.request().newBuilder()
                .apply {
                    // 如果存在token，添加到请求头
                    token?.let {
                        addHeader("token", it)
                    }
                }
                .build()
            chain.proceed(request)
        }

        return OkHttpClient.Builder()
            .connectTimeout(NetworkConfig.CONNECT_TIMEOUT, TimeUnit.MILLISECONDS)
            .readTimeout(NetworkConfig.READ_TIMEOUT, TimeUnit.MILLISECONDS)
            .writeTimeout(NetworkConfig.WRITE_TIMEOUT, TimeUnit.MILLISECONDS)
            .cache(cache)
            .addInterceptor(loggingInterceptor)
            .addInterceptor { chain ->
                val request = chain.request().newBuilder()
                    .addHeader("User-Agent", "Android/${Build.VERSION.RELEASE}")
                    .addHeader("Content-Type", "application/json")
                    .addHeader("Accept", "application/json")
                    .build()
                chain.proceed(request)
            }
            .addInterceptor(tokenInterceptor) // 添加token拦截器
            .build()
    }
    
    /**
     * 获取API服务实例
     */
    fun getApiService(): ApiService {
        if (!::apiService.isInitialized) {
            throw IllegalStateException("RetrofitManager has not been initialized")
        }
        return apiService
    }
}
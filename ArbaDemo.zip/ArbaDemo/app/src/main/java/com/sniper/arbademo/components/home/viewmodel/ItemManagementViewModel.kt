package com.sniper.arbademo.components.home.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sniper.arbademo.components.home.model.ItemListData
import com.sniper.arbademo.components.home.repository.ItemRepository
import com.sniper.arbademo.network.NetworkCallback
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * 物品管理ViewModel
 */
class ItemManagementViewModel : ViewModel() {
    private val repository = ItemRepository()
    
    // 物品列表状态
    private val _itemsState = MutableStateFlow<ItemsUiState>(ItemsUiState.Idle)
    val itemsState: StateFlow<ItemsUiState> = _itemsState.asStateFlow()
    
    /**
     * 获取物品列表
     */
    fun loadItems() {
        viewModelScope.launch {
            _itemsState.value = ItemsUiState.Loading
        }
        
        repository.getItemList(object : NetworkCallback<ItemListData> {

            override fun onSuccess(data: ItemListData) {
                viewModelScope.launch {
                    _itemsState.value = ItemsUiState.Success(data)
                }
            }

            override fun onFailure(errorCode: Int, errorMsg: String) {
                viewModelScope.launch {
                    _itemsState.value = ItemsUiState.Error(errorMsg)
                }
            }
            
            override fun onComplete() {
                // 可以在这里添加完成后的通用逻辑
            }
        })
    }
    
    /**
     * 物品列表UI状态密封类
     */
    sealed class ItemsUiState {
        object Idle : ItemsUiState()
        object Loading : ItemsUiState()
        data class Success(val items: ItemListData) : ItemsUiState()
        data class Error(val message: String) : ItemsUiState()
    }
}
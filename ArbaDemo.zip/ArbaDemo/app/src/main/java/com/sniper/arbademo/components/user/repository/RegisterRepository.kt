package com.sniper.arbademo.components.user.repository

import com.sniper.arbademo.components.user.model.UserResponse
import com.sniper.arbademo.network.NetworkCallback
import com.sniper.arbademo.network.NetworkClient
import com.sniper.arbademo.network.RetrofitManager

/**
 * 注册仓库类，负责处理注册相关的数据操作
 */
class RegisterRepository {
    
    /**
     * 执行注册
     * @param username 用户名
     * @param password 密码
     * @param confirmPassword 确认密码
     * @param callback 回调接口
     */
    fun register(username: String, password: String, confirmPassword: String, callback: NetworkCallback<UserResponse>) {
        NetworkClient.request(
            request = { 
                RetrofitManager.getApiService().register(username, password, confirmPassword) 
            },
            callback = object : NetworkCallback<Map<String, Any>> {
                override fun onSuccess(data: Map<String, Any>) {
                    // 解析嵌套的userinfo数据
                    val userInfo = data["userinfo"] as? Map<String, Any> ?: emptyMap()
                    
                    // 将Map转换为UserResponse对象
                    val userResponse = UserResponse(
                        id = (userInfo["id"] as? Number)?.toInt() ?: 0,
                        username = userInfo["username"]?.toString() ?: username,
                        nickname = userInfo["nickname"]?.toString() ?: username,
                        mobile = userInfo["mobile"]?.toString() ?: "",
                        avatar = userInfo["avatar"]?.toString() ?: "",
                        score = (userInfo["score"] as? Number)?.toInt() ?: 0,
                        token = userInfo["token"]?.toString() ?: "",
                        user_id = (userInfo["user_id"] as? Number)?.toInt() ?: 0,
                        createtime = (userInfo["createtime"] as? Number)?.toLong() ?: 0,
                        expiretime = (userInfo["expiretime"] as? Number)?.toLong() ?: 0,
                        expires_in = (userInfo["expires_in"] as? Number)?.toInt() ?: 0
                    )
                    callback.onSuccess(userResponse)
                }
                
                override fun onFailure(errorCode: Int, errorMsg: String) {
                    callback.onFailure(errorCode, errorMsg)
                }
                
                override fun onComplete() {
                    callback.onComplete()
                }
            }
        )
    }
}
package com.sniper.arbademo.components.home.viewmodel

import androidx.lifecycle.ViewModel
import com.sniper.arbademo.components.home.model.ItemListData
import com.sniper.arbademo.components.home.repository.CheckInRepository
import com.sniper.arbademo.network.NetworkCallback

/**
 * 打卡页面ViewModel，负责管理物品列表数据和UI状态
 */
class CheckInViewModel : ViewModel() {
    // 仓库实例
    private val checkInRepository = CheckInRepository()
    
    /**
     * UI状态监听器接口
     */
    interface ItemsStateListener {
        fun onLoading()
        fun onSuccess(items: ItemListData?)
        fun onError(message: String)
    }
    
    /**
     * 加载物品列表
     * @param listener 状态监听器
     */
    fun loadItems(listener: ItemsStateListener) {
        // 通知加载开始
        listener.onLoading()
        
        // 通过仓库获取数据
        checkInRepository.getItemList(object : NetworkCallback<ItemListData> {
            override fun onSuccess(data: ItemListData) {
                listener.onSuccess(data)
            }
            
            override fun onFailure(errorCode: Int, errorMsg: String) {
                listener.onError(errorMsg)
            }
            
            override fun onComplete() {
                // 完成回调，不做特殊处理
            }
        })
    }
}
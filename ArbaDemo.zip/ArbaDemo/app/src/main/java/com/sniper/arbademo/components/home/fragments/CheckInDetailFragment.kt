package com.sniper.arbademo.components.home.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import coil3.load
import com.sniper.arbademo.R
import com.sniper.arbademo.manager.FileUploadManager
import com.sniper.arbademo.network.NetworkCallback
import com.sniper.arbademo.base.fragment.BaseFragment
import com.sniper.arbademo.components.camera.manager.CameraManager
import com.sniper.arbademo.components.home.model.Item
import com.sniper.arbademo.components.home.viewmodel.CheckInDetailViewModel
import com.sniper.arbademo.databinding.FragmentCheckInDetailBinding
import java.io.File

/**
 * 打卡详情页面Fragment
 * 支持新增打卡和编辑打卡功能
 */
class CheckInDetailFragment : BaseFragment() {
    private lateinit var viewModel: CheckInDetailViewModel
    private var _binding: FragmentCheckInDetailBinding? = null
    private val binding get() = _binding!!
    
    // 参数常量
    private val ARG_ITEM_ID = "item_id"
    private val ARG_ITEM_NAME = "item_name"
    private val ARG_ITEM_CONTENT = "item_content"
    private val ARG_CHECK_IN_ITEM = "check_in_item"
    
    // 页面状态标记
    private var isEditMode = false
    private var isCheckInMode = false
    
    // 打卡相关变量
    private var checkInItem: Item? = null
//    private var imageUri: android.net.Uri? = null
    private var currentPhotoPath: String? = null
    private val REQUEST_IMAGE_CAPTURE = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let { bundle ->
            // 检查是否有id参数，判断是编辑模式还是新增模式
//            isEditMode = bundle.getString(ARG_ITEM_ID, "").isNotEmpty()
            
            // 检查是否是打卡模式
            isCheckInMode = bundle.containsKey(ARG_CHECK_IN_ITEM)
            if (isCheckInMode) {
                checkInItem = bundle.getParcelable(ARG_CHECK_IN_ITEM, Item::class.java)
            }
        }
        
        // 提前初始化CameraManager，确保在Fragment创建前注册ActivityResultLauncher
        if (isCheckInMode) {
            CameraManager.getInstance().initialize(this)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentCheckInDetailBinding.inflate(inflater, container, false)
        
        // 初始化ViewModel
        viewModel = ViewModelProvider(this)[CheckInDetailViewModel::class.java]
        
        // 设置参数
        arguments?.let { bundle ->
            val name = bundle.getString(ARG_ITEM_NAME, "")
            val content = bundle.getString(ARG_ITEM_CONTENT, "")
            
            // 反显数据（编辑模式）
            if (isEditMode) {
                binding.etItemName.setText(name)
                binding.etItemContent.setText(content)
            }
            
            // 打卡模式下显示物品信息
            if (isCheckInMode && checkInItem != null) {
                binding.etItemName.setText(checkInItem!!.name)
                binding.etItemContent.setText(checkInItem!!.content)
                // 打卡模式下禁止编辑
                binding.etItemName.isEnabled = false
                binding.etItemContent.isEnabled = false
                
                // 显示拍照按钮和预览区域
                binding.btnTakePhoto.visibility = View.VISIBLE
                binding.ivPhotoPreview.visibility = View.VISIBLE
                binding.tvPhotoLabel.visibility = View.VISIBLE
            }
        }
        
        // 设置标题
        if (isCheckInMode) {
            binding.tvTitle.text = "物品打卡"
            binding.btnConfirm.text = "确认打卡"
        } else {
            binding.tvTitle.text = if (isEditMode) "编辑打卡" else "新增打卡"
        }
        
        // 设置确认按钮点击事件
        binding.btnConfirm.setOnClickListener {
//            if (isCheckInMode) {
                performCheckIn()
//            } else {
//                saveCheckIn()
//            }
        }
        
        // 设置返回按钮点击事件
        binding.btnBack.setOnClickListener {
            requireActivity().onBackPressedDispatcher.onBackPressed()
        }
        
        // 设置拍照按钮点击事件（仅在打卡模式下可见）
        binding.btnTakePhoto.setOnClickListener {
            takePhotoWithCameraManager()
        }
        
        return binding.root
    }
    
    /**
     * 使用CameraManager拍照
     */
    private fun takePhotoWithCameraManager() {
        try {
            CameraManager.takePhoto(this) {
            onImageCaptured = { imageFile ->
                // 拍照成功，保存图片路径并显示预览
                currentPhotoPath = imageFile.absolutePath
                binding.ivPhotoPreview.load(imageFile) {
//                    placeholder(R.drawable.ic_launcher_background)
//                    error(R.drawable.ic_launcher_foreground)
                }
            }
            onCameraCanceled = {
                // 相机被取消
                Toast.makeText(requireContext(), "拍照已取消", Toast.LENGTH_SHORT).show()
            }
            onError = {
                // 拍照出错
                Toast.makeText(requireContext(), "拍照失败，请重试", Toast.LENGTH_SHORT).show()
            }
        }
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(requireContext(), "启动相机失败: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
    
    /**
     * 保存打卡记录
     */
    private fun saveCheckIn() {
        val name = binding.etItemName.text.toString().trim()
        val content = binding.etItemContent.text.toString().trim()
        
        // 简单校验
        if (name.isEmpty()) {
            Toast.makeText(requireContext(), "请输入名称", Toast.LENGTH_SHORT).show()
            return
        }
        
        // 创建Item对象
        val item = Item(
            name = name,
            content = content,
            itemimage = ""
        )
        
        // 调用ViewModel保存数据
        viewModel.saveCheckIn(item, object : CheckInDetailViewModel.SaveListener {
            override fun onSuccess() {
                // 保存成功，返回列表页
                requireActivity().runOnUiThread {
                    Toast.makeText(requireContext(), "保存成功", Toast.LENGTH_SHORT).show()
                    
                    // 返回列表页并刷新数据
                    val checkInFragment = parentFragmentManager.findFragmentByTag("CheckInFragment") as? CheckInFragment
                    checkInFragment?.refreshList()
                    
                    requireActivity().onBackPressedDispatcher.onBackPressed()
                }
            }
            
            override fun onError(message: String) {
                // 保存失败
                requireActivity().runOnUiThread {
                    Toast.makeText(requireContext(), "保存失败: $message", Toast.LENGTH_SHORT).show()
                }
            }
        })
    }
    
    /**
     * 执行打卡操作
     */
    private fun performCheckIn() {
        // 前置条件检查
        if (checkInItem == null) {
            showToast("物品信息丢失")
            return
        }
        
        if (currentPhotoPath == null) {
            showToast("请先拍照")
            return
        }
        
        // 显示加载指示器
        showLoading()
        
        // 上传图片
        uploadImageAndCheckIn()
    }
    
    /**
     * 显示加载指示器
     */
    private fun showLoading() {
        requireActivity().runOnUiThread {
            binding.loadingContainer.visibility = View.VISIBLE
        }
    }
    
    /**
     * 隐藏加载指示器
     */
    private fun hideLoading() {
        requireActivity().runOnUiThread {
            binding.loadingContainer.visibility = View.GONE
        }
    }
    
    /**
     * 上传图片并执行打卡
     */
    private fun uploadImageAndCheckIn() {
        val imageFile = File(currentPhotoPath)
        FileUploadManager.uploadFile(imageFile, object : NetworkCallback<String> {
            override fun onSuccess(result: String) {
                // 上传成功后调用打卡接口
                requireActivity().runOnUiThread {
                    callCheckInApi(result)
                }
            }
            
            override fun onFailure(errorCode: Int, errorMessage: String) {
                hideLoading()
                showToast("图片上传失败: $errorMessage")
            }
            
            override fun onComplete() {
                // 上传完成回调，可用于隐藏加载指示器等
            }
        })
    }
    
    /**
     * 调用打卡API
     */
    private fun callCheckInApi(fileUrl: String) {
        viewModel.performCheckIn(checkInItem!!.id.toString(), fileUrl, object : CheckInDetailViewModel.CheckInListener {
            override fun onSuccess() {
                hideLoading()
                showToast("打卡成功")
                requireActivity().onBackPressedDispatcher.onBackPressed()
            }
            
            override fun onError(message: String) {
                hideLoading()
                showToast("打卡失败: $message")
            }
        })
    }
    
    /**
     * 显示Toast消息的辅助方法
     */
    override fun showToast(message: String) {
        requireActivity().runOnUiThread {
            Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
        }
    }
    
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        /**
         * 使用此工厂方法创建新的Fragment实例
         *
         * @param itemId 项目ID，空字符串表示新增
         * @param itemName 项目名称
         * @param itemContent 项目内容
         * @return CheckInDetailFragment实例
         */
        @JvmStatic
        fun newInstance(itemId: String = "", itemName: String = "", itemContent: String = "") =
            CheckInDetailFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_ITEM_ID, itemId)
                    putString(ARG_ITEM_NAME, itemName)
                    putString(ARG_ITEM_CONTENT, itemContent)
                }
            }
        
        /**
         * 用于打卡模式的工厂方法
         * @param item 要打卡的物品
         * @return CheckInDetailFragment实例
         */
        @JvmStatic
        fun newInstanceForCheckIn(item: Item) = CheckInDetailFragment().apply {
            arguments = Bundle().apply {
                putParcelable(ARG_CHECK_IN_ITEM, item)
            }
        }
    }
}